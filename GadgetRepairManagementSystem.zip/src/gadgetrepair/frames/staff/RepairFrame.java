/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gadgetrepair.frames.staff;

import gadgetrepair.frames.staff.DashboardFrame;
import gadgetrepair.data.DatabaseConnection;
import gadgetrepair.frames.admin.AdminDashboardFrame;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class RepairFrame extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger =
        java.util.logging.Logger.getLogger(RepairFrame.class.getName());

    private String userRole;
    private String username;
    private boolean editMode = false;

    private void loadGadgetsByCustomer() {

    cmbGadget.removeAllItems();
    cmbGadget.addItem("Select Gadget");

    txtProblem.setText("");

    String customerIdText =
            txtSelectedCustomerId.getText().trim();

    if (customerIdText.isEmpty()) {
        return;
    }

    try {

        int customerId =
                Integer.parseInt(customerIdText);

        String sql =
    "SELECT g.gadget_id, gt.gadget_type_name, g.brand_model " +
    "FROM gadgets g " +
    "JOIN gadget_types gt " +
    "ON g.gadget_type_id = gt.gadget_type_id " +
    "WHERE g.customer_id = ? " +
    "AND g.is_active = 1";

        try (
            Connection conn =
                    DatabaseConnection.getConnection();
            PreparedStatement pst =
                    conn.prepareStatement(sql)
        ) {

            pst.setInt(1, customerId);

            try (ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {

                    cmbGadget.addItem(
                            rs.getInt("gadget_id")
                            + " - "
                            + rs.getString("gadget_type_name")
                            + " - "
                            + rs.getString("brand_model")
                    );
                }
            }
        }

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
                this,
                "Invalid Customer ID."
        );

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading gadgets:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
      
  private void loadTechnicians() {

   
    cmbRepairTechnician.removeAllItems();

    String sql =
        "SELECT t.technician_id, " +
        "CONCAT(u.first_name, ' ', u.last_name) AS technician_name " +
        "FROM technicians t " +
        "JOIN users u ON t.account_id = u.account_id " +
        "JOIN accounts a ON t.account_id = a.account_id " +
        "WHERE a.is_active = 1 " +
        "ORDER BY u.first_name, u.last_name";

    int count = 0;

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery()
    ) {

        while (rs.next()) {

            String technician =
                rs.getInt("technician_id")
                + " - "
                + rs.getString("technician_name");

            cmbRepairTechnician.addItem(technician);

            count++;
        }

        cmbRepairTechnician.insertItemAt(
            "Select Technician",
            0
        );

        cmbRepairTechnician.setSelectedIndex(0);



    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading technicians:\n" + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
    
     private void loadProblemFromSelectedGadget() {

        if (
            cmbGadget.getSelectedItem() == null ||
            cmbGadget.getSelectedIndex() == 0
        ) {

            txtProblem.setText("");
            return;
        }

        String gadgetText =
            cmbGadget.getSelectedItem().toString();

        try {

            int gadgetId =
                Integer.parseInt(
                    gadgetText.split(" - ")[0]
                );

            String sql =
                "SELECT problem " +
                "FROM gadgets " +
                "WHERE gadget_id = ? " +
                "AND is_active = 1";

            try (
                Connection conn =
                    DatabaseConnection.getConnection();

                PreparedStatement pst =
                    conn.prepareStatement(sql)
            ) {

                pst.setInt(1, gadgetId);

                try (ResultSet rs =
                    pst.executeQuery()) {

                    if (rs.next()) {

                        txtProblem.setText(
                            rs.getString("problem")
                        );

                    } else {

                        txtProblem.setText("");
                    }
                }
            }

        } catch (
            NumberFormatException |
            SQLException e
        ) {

            txtProblem.setText("");

            JOptionPane.showMessageDialog(
                this,
                "Error loading gadget problem:\n"
                + e.getMessage()
            );
        }
    }

   
    private void refreshRepairTable() {

        DefaultTableModel model =
            (DefaultTableModel) tblRepairs.getModel();

        model.setRowCount(0);

        String sql =
            "SELECT r.repair_id, " +
    "CONCAT(c.first_name, ' ', c.last_name) AS customer_name, " +
    "CONCAT(gt.gadget_type_name, ' - ', g.brand_model) AS gadget_name, " +
    "r.repair_description, " +
    "a.username AS technician_name, " +
    "r.repair_status, " +
    "r.date_brought " +
    "FROM repairs r " +
    "JOIN gadgets g " +
    "ON r.gadget_id = g.gadget_id " +
    "JOIN gadget_types gt " +
    "ON g.gadget_type_id = gt.gadget_type_id " +
    "JOIN customers c " +
    "ON g.customer_id = c.customer_id " +
    "LEFT JOIN technicians t " +
    "ON r.technician_id = t.technician_id " +
    "LEFT JOIN accounts a " +
    "ON t.account_id = a.account_id " +
    "WHERE r.is_archived = 0 " +
    "ORDER BY r.repair_id ASC";

        try (
            Connection conn =
                DatabaseConnection.getConnection();

            PreparedStatement pst =
                conn.prepareStatement(sql);

            ResultSet rs =
                pst.executeQuery()
        ) {

            while (rs.next()) {

                model.addRow(new Object[]{
                    rs.getInt("repair_id"),
                    rs.getString("customer_name"),
                    rs.getString("gadget_name"),
                    rs.getString("repair_description"),
                    rs.getString("technician_name"),
                    rs.getString("repair_status"),
                    rs.getDate("date_brought")
                });
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this,
                "Error loading repairs:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
  
    
    private void clearRepairFields() {

    txtSelectedCustomerId.setText("");
    txtSelectedCustomerName.setText("");
    txtSelectedContact.setText("");

    cmbGadget.setSelectedIndex(-1);

    txtProblem.setText("");

    cmbRepairTechnician.setSelectedIndex(-1);

    cmbRepairStatus.setSelectedIndex(-1);

    cldrDate.setDate(null);

    tblCustomerResults.clearSelection();
}

    
  public RepairFrame(String username, String userRole) {

    initComponents();

    this.username = username;
    this.userRole = userRole;

    setLocationRelativeTo(null);
    

    tblRepairs.setModel(new DefaultTableModel(
        new Object[][] {},
        new String[] {
            "Repair ID",
            "Customer",
            "Gadget",
            "Problem",
            "Repair Technician",
            "Status",
            "Date Brought"
        }
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    });

    // Customer search table
    tblCustomerResults.setModel(new DefaultTableModel(
        new Object[][] {},
        new String[] {
            "Customer ID",
            "Customer Name",
            "Contact Number"
        }
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    });

    txtRepairId.setEditable(false);

    txtSelectedCustomerId.setEditable(false);
    txtSelectedCustomerName.setEditable(false);
    txtSelectedContact.setEditable(false);

    txtProblem.setEditable(false);

    cmbGadget.removeAllItems();
    cmbGadget.addItem("Select Gadget");


    cmbRepairStatus.setSelectedItem("Pending");

    cldrDate.setDate(new java.util.Date());

    refreshRepairTable();
    loadTechnicians();
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        txtTitle = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        txtRepairId = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cmbRepairTechnician = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        cmbGadget = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        cmbRepairStatus = new javax.swing.JComboBox<>();
        cldrDate = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();
        txtCustomerSearch = new javax.swing.JTextField();
        btnSearchCustomer = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtProblem = new javax.swing.JTextArea();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        txtSelectedCustomerId = new javax.swing.JTextField();
        txtSelectedCustomerName = new javax.swing.JTextField();
        txtSelectedContact = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblCustomerResults = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel10 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtSearchRepair = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        btnBack = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblRepairs = new javax.swing.JTable();
        btnCreate = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(18, 52, 86));
        jPanel1.setPreferredSize(new java.awt.Dimension(850, 80));

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\LOGO REPAIRsss.png")); // NOI18N
        jLabel8.setPreferredSize(new java.awt.Dimension(135, 135));

        txtTitle.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        txtTitle.setForeground(new java.awt.Color(242, 242, 242));
        txtTitle.setText("REPAIR MANAGEMENT");
        txtTitle.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(583, Short.MAX_VALUE)
                .addComponent(txtTitle)
                .addGap(282, 282, 282)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtTitle)
                .addGap(23, 23, 23))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1540, 116));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jPanel2.setPreferredSize(new java.awt.Dimension(300, 230));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel9.setText("REPAIR INFORMATION");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(109, 15, -1, -1));

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 53, 1530, 10));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel2.setText("Repair ID:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        txtRepairId.setEditable(false);
        txtRepairId.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtRepairId.addActionListener(this::txtRepairIdActionPerformed);
        jPanel2.add(txtRepairId, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 70, 200, 40));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel3.setText("Problem:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 480, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel4.setText("Repair Technician:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 560, -1, -1));

        cmbRepairTechnician.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cmbRepairTechnician.addActionListener(this::cmbRepairTechnicianActionPerformed);
        jPanel2.add(cmbRepairTechnician, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 560, 200, 40));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel5.setText("Date Brought:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 650, -1, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel11.setText("Gadget:");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 440, -1, -1));

        cmbGadget.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cmbGadget.addActionListener(this::cmbGadgetActionPerformed);
        jPanel2.add(cmbGadget, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 440, 200, 30));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel12.setText("Status:");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 610, -1, -1));

        cmbRepairStatus.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cmbRepairStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Status", "Pending", "In Progress", "Completed" }));
        cmbRepairStatus.addActionListener(this::cmbRepairStatusActionPerformed);
        jPanel2.add(cmbRepairStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 610, 200, 30));
        jPanel2.add(cldrDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 650, 390, 30));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Search Customer:");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));

        txtCustomerSearch.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jPanel2.add(txtCustomerSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 130, 195, 30));

        btnSearchCustomer.setBackground(new java.awt.Color(24, 91, 160));
        btnSearchCustomer.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnSearchCustomer.setForeground(new java.awt.Color(255, 255, 255));
        btnSearchCustomer.setText("Search");
        btnSearchCustomer.addActionListener(this::btnSearchCustomerActionPerformed);
        jPanel2.add(btnSearchCustomer, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 130, 130, 30));

        txtProblem.setEditable(false);
        txtProblem.setColumns(20);
        txtProblem.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtProblem.setRows(5);
        jScrollPane3.setViewportView(txtProblem);

        jPanel2.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 480, 390, 66));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel13.setText("Selected Customer:");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel14.setText("Customer ID:");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 150, 20));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel15.setText("Customer Name:");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 360, 180, -1));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel16.setText("Contact Number:");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 400, -1, 25));

        txtSelectedCustomerId.setEditable(false);
        txtSelectedCustomerId.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtSelectedCustomerId.addActionListener(this::txtSelectedCustomerIdActionPerformed);
        jPanel2.add(txtSelectedCustomerId, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 310, 195, 30));

        txtSelectedCustomerName.setEditable(false);
        txtSelectedCustomerName.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtSelectedCustomerName.addActionListener(this::txtSelectedCustomerNameActionPerformed);
        jPanel2.add(txtSelectedCustomerName, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 360, 195, 30));

        txtSelectedContact.setEditable(false);
        txtSelectedContact.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtSelectedContact.addActionListener(this::txtSelectedContactActionPerformed);
        jPanel2.add(txtSelectedContact, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 400, 195, 30));

        tblCustomerResults.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        tblCustomerResults.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Customer ID", "Customer Name", "Contact Number"
            }
        ));
        tblCustomerResults.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblCustomerResultsMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tblCustomerResults);

        jPanel2.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 180, 380, 110));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jPanel3.setPreferredSize(new java.awt.Dimension(550, 330));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        jPanel3.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 1747, 10));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setText("REPAIR RECORDS");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel6.setText("Search :");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 98, -1));

        txtSearchRepair.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtSearchRepair.addActionListener(this::txtSearchRepairActionPerformed);
        jPanel3.add(txtSearchRepair, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 50, 140, 30));

        btnSearch.setBackground(new java.awt.Color(24, 91, 160));
        btnSearch.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setText("SEARCH");
        btnSearch.addActionListener(this::btnSearchActionPerformed);
        jPanel3.add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 50, 130, 30));

        jScrollPane2.setPreferredSize(new java.awt.Dimension(500, 100));
        jPanel3.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1101, 129, 641, 374));

        btnBack.setBackground(new java.awt.Color(15, 43, 77));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(this::btnBackActionPerformed);
        jPanel3.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 470, 140, 40));

        tblRepairs.setBackground(new java.awt.Color(15, 43, 77));
        tblRepairs.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tblRepairs.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        tblRepairs.setForeground(new java.awt.Color(255, 255, 255));
        tblRepairs.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Repair ID", "Customer ", "Gadget", "Problem", "Repair Technician", "Status", "Date Brought"
            }
        ));
        jScrollPane1.setViewportView(tblRepairs);

        jScrollPane5.setViewportView(jScrollPane1);

        jPanel3.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, 110, 850, 340));

        btnCreate.setBackground(new java.awt.Color(24, 91, 160));
        btnCreate.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnCreate.setForeground(new java.awt.Color(255, 255, 255));
        btnCreate.setText("CREATE");
        btnCreate.addActionListener(this::btnCreateActionPerformed);
        jPanel3.add(btnCreate, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 570, 140, -1));

        btnEdit.setBackground(new java.awt.Color(24, 91, 160));
        btnEdit.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnEdit.setForeground(new java.awt.Color(255, 255, 255));
        btnEdit.setText("EDIT");
        btnEdit.addActionListener(this::btnEditActionPerformed);
        jPanel3.add(btnEdit, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 570, 140, -1));

        btnSave.setBackground(new java.awt.Color(24, 91, 160));
        btnSave.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnSave.setForeground(new java.awt.Color(255, 255, 255));
        btnSave.setText("SAVE");
        btnSave.addActionListener(this::btnSaveActionPerformed);
        jPanel3.add(btnSave, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 570, 140, -1));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 70, 795, 660));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 1520, 770));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreateActionPerformed

    String customerIdText =
            txtSelectedCustomerId.getText().trim();

    // 1. Customer must be selected
    if (customerIdText.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "Please search and select a customer first."
        );

        return;
    }

    // 2. Gadget must be selected
    if (cmbGadget.getSelectedIndex() <= 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a gadget."
        );

        return;
    }

    if (cmbRepairTechnician.getSelectedIndex() <= 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a technician."
        );

        return;
    }

    if (cmbRepairStatus.getSelectedIndex() <= 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a repair status."
        );

        return;
    }

    if (cldrDate.getDate() == null) {

        JOptionPane.showMessageDialog(
                this,
                "Please select the date brought."
        );

        return;
    }

    try {

        int customerId =
                Integer.parseInt(customerIdText);

        int gadgetId =
                Integer.parseInt(
                        cmbGadget.getSelectedItem()
                                .toString()
                                .split(" - ")[0]
                );

        int technicianId =
                Integer.parseInt(
                        cmbRepairTechnician.getSelectedItem()
                                .toString()
                                .split(" - ")[0]
                );

        String status =
                cmbRepairStatus.getSelectedItem()
                        .toString();

        String problem =
                txtProblem.getText().trim();

        if (problem.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "The selected gadget has no recorded problem."
            );

            return;
        }

        String dateBrought =
                new java.text.SimpleDateFormat(
                        "yyyy-MM-dd"
                ).format(cldrDate.getDate());

        try (
                Connection conn =
                        DatabaseConnection.getConnection()
        ) {

            String checkSql =
                    "SELECT gadget_id " +
                    "FROM gadgets " +
                    "WHERE gadget_id = ? " +
                    "AND customer_id = ? " +
                    "AND is_active = 1";

            try (
                    PreparedStatement checkPst =
                            conn.prepareStatement(checkSql)
            ) {

                checkPst.setInt(1, gadgetId);
                checkPst.setInt(2, customerId);

                try (ResultSet rs =
                        checkPst.executeQuery()) {

                    if (!rs.next()) {

                        JOptionPane.showMessageDialog(
                                this,
                                "The selected gadget does not belong " +
                                "to the selected customer."
                        );

                        return;
                    }
                }
            }

            String sql =
                    "INSERT INTO repairs " +
                    "(gadget_id, technician_id, " +
                    "repair_description, repair_status, " +
                    "date_brought, is_archived) " +
                    "VALUES (?, ?, ?, ?, ?, 0)";

            try (
                    PreparedStatement pst =
                            conn.prepareStatement(sql)
            ) {

                pst.setInt(1, gadgetId);
                pst.setInt(2, technicianId);
                pst.setString(3, problem);
                pst.setString(4, status);
                pst.setString(5, dateBrought);

                pst.executeUpdate();
            }
        }

        JOptionPane.showMessageDialog(
                this,
                "Repair created successfully!"
        );

        refreshRepairTable();

        clearRepairFields();

        cmbGadget.setSelectedIndex(0);
        cmbRepairTechnician.setSelectedIndex(0);
        cmbRepairStatus.setSelectedItem("Pending");
        cldrDate.setDate(new java.util.Date());

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
                this,
                "Invalid Customer, Gadget, or Technician ID."
        );

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error creating repair:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    // TODO add your handling code here:
    }//GEN-LAST:event_btnCreateActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
  

    int row = tblRepairs.getSelectedRow();

    if (row < 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a repair to edit."
        );

        return;
    }

    int repairId =
            Integer.parseInt(
                    tblRepairs.getValueAt(row, 0).toString()
            );

    String sql =
            "SELECT r.repair_id, " +
            "r.gadget_id, " +
            "r.technician_id, " +
            "r.repair_description, " +
            "r.repair_status, " +
            "r.date_brought, " +
            "g.customer_id, " +
            "c.first_name, " +
            "c.last_name, " +
            "c.contact_number " +
            "FROM repairs r " +
            "JOIN gadgets g ON r.gadget_id = g.gadget_id " +
            "JOIN customers c ON g.customer_id = c.customer_id " +
            "WHERE r.repair_id = ? " +
            "AND r.is_archived = 0";

    try (
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pst = conn.prepareStatement(sql)
    ) {

        pst.setInt(1, repairId);

        try (ResultSet rs = pst.executeQuery()) {

            if (!rs.next()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Repair not found."
                );

                return;
            }

            txtRepairId.setText(
                    String.valueOf(
                            rs.getInt("repair_id")
                    )
            );

            int customerId =
                    rs.getInt("customer_id");

            txtSelectedCustomerId.setText(
                    String.valueOf(customerId)
            );

            txtSelectedCustomerName.setText(
                    rs.getString("first_name")
                    + " "
                    + rs.getString("last_name")
            );

            txtSelectedContact.setText(
                    rs.getString("contact_number")
            );

            loadGadgetsByCustomer();

            int gadgetId =
                    rs.getInt("gadget_id");

            for (int i = 0;
                 i < cmbGadget.getItemCount();
                 i++) {

                String item =
                        cmbGadget.getItemAt(i);

                if (item.startsWith(gadgetId + " - ")) {

                    cmbGadget.setSelectedIndex(i);
                    break;
                }
            }

            int technicianId =
                    rs.getInt("technician_id");

            for (int i = 0;
                 i < cmbRepairTechnician.getItemCount();
                 i++) {

                String item =
                        cmbRepairTechnician.getItemAt(i);

                if (item.startsWith(technicianId + " - ")) {

                    cmbRepairTechnician.setSelectedIndex(i);
                    break;
                }
            }

            cmbRepairStatus.setSelectedItem(
                    rs.getString("repair_status")
            );

            cldrDate.setDate(
                    rs.getDate("date_brought")
            );

            loadProblemFromSelectedGadget();

            editMode = true;
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading repair:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
   
   // TODO add your handling code here:
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed


    String repairIdText =
            txtRepairId.getText().trim();

    String customerIdText =
            txtSelectedCustomerId.getText().trim();

    if (repairIdText.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "Please click EDIT on a repair first."
        );
        return;
    }

    if (customerIdText.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "Please select a customer."
        );
        return;
    }

    if (cmbGadget.getSelectedIndex() <= 0) {
        JOptionPane.showMessageDialog(
                this,
                "Please select a gadget."
        );
        return;
    }

    if (cmbRepairTechnician.getSelectedIndex() <= 0) {
        JOptionPane.showMessageDialog(
                this,
                "Please select a technician."
        );
        return;
    }

    if (cmbRepairStatus.getSelectedIndex() <= 0) {
        JOptionPane.showMessageDialog(
                this,
                "Please select a repair status."
        );
        return;
    }

    if (cldrDate.getDate() == null) {
        JOptionPane.showMessageDialog(
                this,
                "Please select the date brought."
        );
        return;
    }

    try {

        int repairId =
                Integer.parseInt(repairIdText);

        int customerId =
                Integer.parseInt(customerIdText);

        int gadgetId =
                Integer.parseInt(
                        cmbGadget.getSelectedItem()
                                .toString()
                                .split(" - ")[0]
                );

        int technicianId =
                Integer.parseInt(
                        cmbRepairTechnician.getSelectedItem()
                                .toString()
                                .split(" - ")[0]
                );

        String status =
                cmbRepairStatus.getSelectedItem()
                        .toString();

        String problem =
                txtProblem.getText().trim();

        if (problem.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "The selected gadget has no recorded problem."
            );
            return;
        }

        String dateBrought =
                new java.text.SimpleDateFormat(
                        "yyyy-MM-dd"
                ).format(cldrDate.getDate());

        try (
                Connection conn =
                        DatabaseConnection.getConnection()
        ) {

            // Make sure the gadget belongs to the selected customer
            String checkSql =
                    "SELECT gadget_id " +
                    "FROM gadgets " +
                    "WHERE gadget_id = ? " +
                    "AND customer_id = ? " +
                    "AND is_active = 1";

            try (
                    PreparedStatement checkPst =
                            conn.prepareStatement(checkSql)
            ) {

                checkPst.setInt(1, gadgetId);
                checkPst.setInt(2, customerId);

                try (ResultSet rs =
                        checkPst.executeQuery()) {

                    if (!rs.next()) {

                        JOptionPane.showMessageDialog(
                                this,
                                "The selected gadget does not belong " +
                                "to the selected customer."
                        );

                        return;
                    }
                }
            }

            // Update the repair
            String sql =
                    "UPDATE repairs SET " +
                    "gadget_id = ?, " +
                    "technician_id = ?, " +
                    "repair_description = ?, " +
                    "repair_status = ?, " +
                    "date_brought = ? " +
                    "WHERE repair_id = ? " +
                    "AND is_archived = 0";

            try (
                    PreparedStatement pst =
                            conn.prepareStatement(sql)
            ) {

                pst.setInt(1, gadgetId);
                pst.setInt(2, technicianId);
                pst.setString(3, problem);
                pst.setString(4, status);
                pst.setString(5, dateBrought);
                pst.setInt(6, repairId);

                int rowsUpdated =
                        pst.executeUpdate();

                if (rowsUpdated == 0) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Repair could not be updated."
                    );

                    return;
                }
            }
        }

        JOptionPane.showMessageDialog(
                this,
                "Repair updated successfully!"
        );

        refreshRepairTable();
        clearRepairFields();
        editMode = false;

        // Exit edit mode
        editMode = false;

        cmbGadget.setSelectedIndex(0);
        cmbRepairTechnician.setSelectedIndex(0);
        cmbRepairStatus.setSelectedItem("Pending");
        cldrDate.setDate(new java.util.Date());

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
                this,
                "Invalid Repair, Customer, Gadget, or Technician ID."
        );

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error updating repair:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
      // TODO add your handling code here:
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed

    String search =
            txtSearchRepair.getText().trim();

    DefaultTableModel model =
            (DefaultTableModel) tblRepairs.getModel();

    model.setRowCount(0);

    if (search.isEmpty()) {
        refreshRepairTable();
        return;
    }

    String sql =
            "SELECT r.repair_id, " +
            "CONCAT(c.first_name, ' ', c.last_name) AS customer_name, " +
            "CONCAT(g.gadget_type, ' - ', g.brand_model) AS gadget_name, " +
            "r.repair_description, " +
            "COALESCE(a.username, 'Unassigned') AS technician_name, " +
            "r.repair_status, " +
            "r.date_brought " +
            "FROM repairs r " +
            "JOIN gadgets g ON r.gadget_id = g.gadget_id " +
            "JOIN customers c ON g.customer_id = c.customer_id " +
            "LEFT JOIN technicians t ON r.technician_id = t.technician_id " +
            "LEFT JOIN accounts a ON t.account_id = a.account_id " +
            "WHERE r.is_archived = 0 " +
            "AND (" +
            "CAST(r.repair_id AS CHAR) LIKE ? " +
            "OR CONCAT(c.first_name, ' ', c.last_name) LIKE ? " +
            "OR g.gadget_type LIKE ? " +
            "OR g.brand_model LIKE ? " +
            "OR r.repair_description LIKE ? " +
            "OR a.username LIKE ? " +
            "OR r.repair_status LIKE ?" +
            ") " +
            "ORDER BY r.repair_id";

    try (
            Connection conn =
                    DatabaseConnection.getConnection();

            PreparedStatement pst =
                    conn.prepareStatement(sql)
    ) {

        String keyword = "%" + search + "%";

        for (int i = 1; i <= 7; i++) {
            pst.setString(i, keyword);
        }

        try (ResultSet rs = pst.executeQuery()) {

            boolean found = false;

            while (rs.next()) {

                model.addRow(new Object[]{
                    rs.getInt("repair_id"),
                    rs.getString("customer_name"),
                    rs.getString("gadget_name"),
                    rs.getString("repair_description"),
                    rs.getString("technician_name"),
                    rs.getString("repair_status"),
                    rs.getDate("date_brought")
                });

                found = true;
            }

            if (!found) {

                JOptionPane.showMessageDialog(
                        this,
                        "No matching repair found."
                );

                refreshRepairTable();
            }
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error searching repairs:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

      // TODO add your handling code here:
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
   
        if ("admin".equalsIgnoreCase(userRole)) {

            new AdminDashboardFrame(username).setVisible(true);

        } else {

            new DashboardFrame(username).setVisible(true);
        }

        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_btnBackActionPerformed

    private void cmbRepairTechnicianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbRepairTechnicianActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbRepairTechnicianActionPerformed

    private void txtSearchRepairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchRepairActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSearchRepairActionPerformed

    private void cmbGadgetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbGadgetActionPerformed
         loadProblemFromSelectedGadget();


       // TODO add your handling code here:
    }//GEN-LAST:event_cmbGadgetActionPerformed

    private void cmbRepairStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbRepairStatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbRepairStatusActionPerformed

    private void txtRepairIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRepairIdActionPerformed

        // TODO add your handling code here:
    }//GEN-LAST:event_txtRepairIdActionPerformed

    private void btnSearchCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchCustomerActionPerformed

        String search =
            txtCustomerSearch.getText().trim();

        DefaultTableModel model =
            (DefaultTableModel) tblCustomerResults.getModel();

        model.setRowCount(0);

        if (search.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Please enter a Customer ID, name, or contact number."
            );

            return;
        }

        String sql =
            "SELECT customer_id, first_name, " +
            "last_name, contact_number " +
            "FROM customers " +
            "WHERE is_active = 1 " +
            "AND (" +
            "CAST(customer_id AS CHAR) LIKE ? " +
            "OR first_name LIKE ? " +
            "OR last_name LIKE ? " +
            "OR contact_number LIKE ?" +
            ") " +
            "ORDER BY customer_id";

        try (
            Connection conn =
                DatabaseConnection.getConnection();

            PreparedStatement pst =
                conn.prepareStatement(sql)
        ) {

            String keyword =
                "%" + search + "%";

            pst.setString(1, keyword);
            pst.setString(2, keyword);
            pst.setString(3, keyword);
            pst.setString(4, keyword);

            try (ResultSet rs =
                pst.executeQuery()) {

                boolean found = false;

                while (rs.next()) {

                    String fullName =
                        rs.getString("first_name")
                        + " "
                        + rs.getString("last_name");

                    model.addRow(
                        new Object[]{
                            rs.getInt("customer_id"),
                            fullName,
                            rs.getString("contact_number")
                        }
                    );

                    found = true;
                }

                if (!found) {

                    JOptionPane.showMessageDialog(
                        this,
                        "Customer not found."
                    );
                }
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this,
                "Error searching customer:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_btnSearchCustomerActionPerformed

    private void tblCustomerResultsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblCustomerResultsMouseClicked
    if (editMode) {
    return;
}
        int row = tblCustomerResults.getSelectedRow();

    if (row < 0) {
        return;
    }

    String customerId =
        tblCustomerResults.getValueAt(row, 0).toString();

    String customerName =
        tblCustomerResults.getValueAt(row, 1).toString();

    String contactNumber =
        tblCustomerResults.getValueAt(row, 2).toString();

    txtSelectedCustomerId.setText(customerId);
    txtSelectedCustomerName.setText(customerName);
    txtSelectedContact.setText(contactNumber);

    // Load only gadgets belonging to this customer
    loadGadgetsByCustomer();
    


        // TODO add your handling code here:
    }//GEN-LAST:event_tblCustomerResultsMouseClicked

    private void txtSelectedCustomerIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSelectedCustomerIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSelectedCustomerIdActionPerformed

    private void txtSelectedCustomerNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSelectedCustomerNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSelectedCustomerNameActionPerformed

    private void txtSelectedContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSelectedContactActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSelectedContactActionPerformed

  
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnCreate;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnSearchCustomer;
    private com.toedter.calendar.JDateChooser cldrDate;
    private javax.swing.JComboBox<String> cmbGadget;
    private javax.swing.JComboBox<String> cmbRepairStatus;
    private javax.swing.JComboBox<String> cmbRepairTechnician;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable tblCustomerResults;
    private javax.swing.JTable tblRepairs;
    private javax.swing.JTextField txtCustomerSearch;
    private javax.swing.JTextArea txtProblem;
    private javax.swing.JTextField txtRepairId;
    private javax.swing.JTextField txtSearchRepair;
    private javax.swing.JTextField txtSelectedContact;
    private javax.swing.JTextField txtSelectedCustomerId;
    private javax.swing.JTextField txtSelectedCustomerName;
    private javax.swing.JLabel txtTitle;
    // End of variables declaration//GEN-END:variables
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gadgetrepair.frames.staff;
import gadgetrepair.frames.staff.DashboardFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import gadgetrepair.data.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author User
 */
public class CompletedRepairFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(CompletedRepairFrame.class.getName());
    private String username;
    private double laborFeeAmount = 0.0;
    private double partsTotalAmount = 0.0;

    private void loadCompletedRepairs() {

    DefaultTableModel model =
        (DefaultTableModel) tblCompletedRepairs.getModel();

    model.setRowCount(0);

    String sql =
       "SELECT r.repair_id, " +
    "CONCAT(c.first_name, ' ', c.last_name) AS customer_name, " +
    "CONCAT(gt.gadget_type_name, ' - ', g.brand_model) AS gadget_name, " +
    "r.repair_description, " +
    "(SELECT GROUP_CONCAT(p.part_name ORDER BY p.part_name SEPARATOR ', ') " +
    " FROM parts p " + " WHERE FIND_IN_SET(CAST(p.part_id AS CHAR), r.parts_used) > 0)"+ 
    " AS parts_used_names, " +
    "a.username AS technician_name, " +
    "r.date_brought, " +
    "r.repair_status " +
    "FROM repairs r " +
    "JOIN gadgets g " +
    "ON r.gadget_id = g.gadget_id " +
    "JOIN gadget_types gt " +
    "ON g.gadget_type_id = gt.gadget_type_id " +
    "JOIN customers c " +
    "ON g.customer_id = c.customer_id " +
    "LEFT JOIN technicians t " +
    "ON r.technician_id = t.technician_id " +
    "LEFT JOIN accounts a " +
    "ON t.account_id = a.account_id " +
    "WHERE r.repair_status = 'Completed' " +
    "AND r.is_archived = 0 " +
    "ORDER BY r.repair_id ASC";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery()
    ) {

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("repair_id"),
                rs.getString("customer_name"),
                rs.getString("gadget_name"),
                rs.getString("repair_description"),
                rs.getString("technician_name"),
                rs.getDate("date_brought"),
                rs.getString("parts_used_names")
            });
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading completed repairs:\n" + e.getMessage()
        );
    }
}
    
    private void calculateRepairCost() {
     int row = tblCompletedRepairs.getSelectedRow();

    if (row < 0) {
        txtRepairCost.setText("");
        return;
    }

    int repairId = Integer.parseInt(
        tblCompletedRepairs.getValueAt(row, 0).toString()
    );

    String sql =
        "SELECT r.repair_description, g.gadget_type_id " +
        "FROM repairs r " +
        "JOIN gadgets g ON r.gadget_id = g.gadget_id " +
        "WHERE r.repair_id = ?";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setInt(1, repairId);

        String description;
        int gadgetTypeId;

        try (ResultSet rs = pst.executeQuery()) {
            if (!rs.next()) {
                txtRepairCost.setText("");
                return;
            }

            description = rs.getString("repair_description");
            gadgetTypeId = rs.getInt("gadget_type_id");
        }

        if (description == null || description.trim().isEmpty()) {
            txtRepairCost.setText("");
            JOptionPane.showMessageDialog(this,
                "No repair problems were recorded.");
            return;
        }

        String[] issues = description.split("\\s*\\|\\s*");
        double laborTotal = 0.0;

        String laborSQL =
            "SELECT labor_fee FROM labor_prices " +
            "WHERE gadget_type_id = ? " +
            "AND LOWER(TRIM(issue_name)) = LOWER(TRIM(?)) " +
            "AND is_active = 1 LIMIT 1";

        try (PreparedStatement laborPst =
                 conn.prepareStatement(laborSQL)) {

            for (String issue : issues) {
                laborPst.setInt(1, gadgetTypeId);
                laborPst.setString(2, issue.trim());

                try (ResultSet laborRs = laborPst.executeQuery()) {
                    if (!laborRs.next()) {
                        txtRepairCost.setText("");
                        JOptionPane.showMessageDialog(this,
                            "No labor fee found for: " + issue);
                        return;
                    }

                    laborTotal += laborRs.getDouble("labor_fee");
                }
            }
        }

        laborFeeAmount = laborTotal;
        partsTotalAmount = calculatePartsTotal(conn, repairId);

double total = laborFeeAmount + partsTotalAmount;

        txtRepairCost.setText(
            String.format(java.util.Locale.US, "%.2f", total)
        );

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Error calculating repair cost: " + e.getMessage());
    }
}
    private void clearRepairDetails() {

    lblRepairId.setText("-");
    lblCustomer.setText("-");
    lblGadget.setText("-");
    lblTechnician.setText("-");
    lblDateBrought.setText("-");
    cldrDateReturned.setDate(null);

    txtProblem.setText("");
    txtRepairCost.setText("");

    cldrDateReturned.setDate(null);
}
    
    private double calculatePartsTotal(Connection conn, int repairId)
        throws SQLException {

    String sql =
        "SELECT COALESCE(SUM(p.part_price), 0) AS parts_total " +
        "FROM repairs r " +
        "JOIN parts p ON FIND_IN_SET(CAST(p.part_id AS CHAR), r.parts_used) > 0 " +
        "WHERE r.repair_id = ?";

    try (PreparedStatement pst = conn.prepareStatement(sql)) {
        pst.setInt(1, repairId);

        try (ResultSet rs = pst.executeQuery()) {
            if (rs.next()) {
                return rs.getDouble("parts_total");
            }
        }
    }

    return 0.0;
}


   public CompletedRepairFrame(String username) {

    initComponents();
   

    this.username = username;

    setLocationRelativeTo(null);

    tblCompletedRepairs.setModel(new DefaultTableModel(
        new Object[][] {},
        new String[] {
             "Repair ID",
             "Customer",
             "Gadget",
             "Problem",
             "Repair Technician",
             "Date Brought",
             "Parts Used"
        }
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    });

    txtProblem.setEditable(false);
    txtRepairCost.setEditable(false);

    clearRepairDetails();

    loadCompletedRepairs();
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtTitle = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        lblRepairId = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lblCustomer = new javax.swing.JLabel();
        lblGadget = new javax.swing.JLabel();
        lblTechnician = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        btnGenerateReceipt = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        scrollCompletedRepairs = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblCompletedRepairs = new javax.swing.JTable();
        jSeparator1 = new javax.swing.JSeparator();
        cldrDateReturned = new com.toedter.calendar.JDateChooser();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtProblem = new javax.swing.JTextArea();
        txtRepairCost = new javax.swing.JTextField();
        btnArchive = new javax.swing.JButton();
        lblDateBrought = new javax.swing.JLabel();
        btnSaveDetails = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(18, 52, 86));
        jPanel1.setPreferredSize(new java.awt.Dimension(900, 80));

        txtTitle.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        txtTitle.setForeground(new java.awt.Color(242, 242, 242));
        txtTitle.setText("COMPLETED REPAIRS");
        txtTitle.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\LOGO REPAIRsss.png")); // NOI18N
        jLabel8.setPreferredSize(new java.awt.Dimension(135, 135));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(570, Short.MAX_VALUE)
                .addComponent(txtTitle)
                .addGap(323, 323, 323)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(txtTitle)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1550, 116));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("SEARCH :");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 140, -1, 30));

        txtSearch.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtSearch.addActionListener(this::txtSearchActionPerformed);
        getContentPane().add(txtSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 140, 120, 30));

        btnSearch.setBackground(new java.awt.Color(15, 43, 77));
        btnSearch.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setText("SEARCH");
        btnSearch.addActionListener(this::btnSearchActionPerformed);
        getContentPane().add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 140, -1, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel4.setText("Repair ID:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 230, -1, -1));

        lblRepairId.setBackground(new java.awt.Color(0, 153, 204));
        lblRepairId.setText("-");
        getContentPane().add(lblRepairId, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 230, 203, 30));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel6.setText("Customer:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 290, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel7.setText("Gadget:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 350, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel9.setText("Technician:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 400, -1, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel10.setText("Problem:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 460, -1, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel11.setText("Date Brought");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 630, -1, -1));

        lblCustomer.setBackground(new java.awt.Color(0, 153, 204));
        lblCustomer.setText("-");
        getContentPane().add(lblCustomer, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 296, 203, 20));

        lblGadget.setBackground(new java.awt.Color(0, 153, 204));
        lblGadget.setText("-");
        getContentPane().add(lblGadget, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 350, 203, 40));

        lblTechnician.setBackground(new java.awt.Color(0, 153, 204));
        lblTechnician.setText("-");
        getContentPane().add(lblTechnician, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 400, 203, 40));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel17.setText("Date Returned:");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 700, -1, -1));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel18.setText("Repair Cost:");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 760, -1, -1));

        btnGenerateReceipt.setBackground(new java.awt.Color(24, 91, 160));
        btnGenerateReceipt.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnGenerateReceipt.setForeground(new java.awt.Color(255, 255, 255));
        btnGenerateReceipt.setText("GENERATE RECEIPT");
        btnGenerateReceipt.addActionListener(this::btnGenerateReceiptActionPerformed);
        getContentPane().add(btnGenerateReceipt, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 620, 240, -1));

        btnBack.setBackground(new java.awt.Color(24, 91, 160));
        btnBack.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(this::btnBackActionPerformed);
        getContentPane().add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 620, 180, -1));

        tblCompletedRepairs.setBackground(new java.awt.Color(15, 43, 77));
        tblCompletedRepairs.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tblCompletedRepairs.setForeground(new java.awt.Color(255, 255, 255));
        tblCompletedRepairs.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "REPAIR ID", "CUSTOMER", "GADGET", "PROBLEM", "REPAIR TECHNICIAN", "DATA BROUGHT"
            }
        ));
        tblCompletedRepairs.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblCompletedRepairsMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblCompletedRepairs);

        scrollCompletedRepairs.setViewportView(jScrollPane1);

        getContentPane().add(scrollCompletedRepairs, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 190, 1000, 400));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1464, 378, 50, 10));
        getContentPane().add(cldrDateReturned, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 700, 203, 40));

        txtProblem.setEditable(false);
        txtProblem.setColumns(20);
        txtProblem.setRows(5);
        jScrollPane3.setViewportView(txtProblem);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 470, 262, 110));

        txtRepairCost.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtRepairCost.addActionListener(this::txtRepairCostActionPerformed);
        getContentPane().add(txtRepairCost, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 760, 203, 40));

        btnArchive.setBackground(new java.awt.Color(24, 91, 160));
        btnArchive.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnArchive.setForeground(new java.awt.Color(255, 255, 255));
        btnArchive.setText("ARCHIVE");
        btnArchive.addActionListener(this::btnArchiveActionPerformed);
        getContentPane().add(btnArchive, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 620, 180, -1));

        lblDateBrought.setBackground(new java.awt.Color(0, 153, 204));
        lblDateBrought.setText("-");
        getContentPane().add(lblDateBrought, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 630, 203, 40));

        btnSaveDetails.setBackground(new java.awt.Color(24, 91, 160));
        btnSaveDetails.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnSaveDetails.setForeground(new java.awt.Color(255, 255, 255));
        btnSaveDetails.setText("SAVE DETAILS");
        btnSaveDetails.addActionListener(this::btnSaveDetailsActionPerformed);
        getContentPane().add(btnSaveDetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 620, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGenerateReceiptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerateReceiptActionPerformed
  int row = tblCompletedRepairs.getSelectedRow();

    if (row == -1) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a completed repair first."
        );
        return;
    }

    String repairId =
        tblCompletedRepairs.getValueAt(row, 0).toString();

    String customer =
        tblCompletedRepairs.getValueAt(row, 1).toString();

    String gadget =
        tblCompletedRepairs.getValueAt(row, 2).toString();

    String problem =
        tblCompletedRepairs.getValueAt(row, 3).toString();

    String technician =
        tblCompletedRepairs.getValueAt(row, 4).toString();

    String dateBrought = lblDateBrought.getText();

    if (cldrDateReturned.getDate() == null) {
        JOptionPane.showMessageDialog(
            this,
            "Please select the date returned."
        );
        return;
    }

    java.text.SimpleDateFormat sdf =
        new java.text.SimpleDateFormat("yyyy-MM-dd");

    String dateReturned =
        sdf.format(cldrDateReturned.getDate());

    String costText = txtRepairCost.getText().trim();

    if (costText.isEmpty()) {
        calculateRepairCost();
        costText = txtRepairCost.getText().trim();
    }

    if (costText.isEmpty()) {
        JOptionPane.showMessageDialog(
            this,
            "Unable to calculate the repair cost. Please check the labor fee and parts."
        );
        return;
    }

    double repairCostValue;

    try {
        repairCostValue = Double.parseDouble(costText);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(
            this,
            "The repair cost is invalid."
        );
        return;
    }

    String repairCost = String.format(
        java.util.Locale.US,
        "₱%,.2f",
        repairCostValue
    );

    ReceiptDialog receipt = new ReceiptDialog(
        this,
        repairId,
        customer,
        gadget,
        problem,
        technician,
        dateBrought,
        dateReturned,
        laborFeeAmount,
        partsTotalAmount,
        repairCost
    );

    receipt.setVisible(true);

        // TODO add your handling code here:
    }//GEN-LAST:event_btnGenerateReceiptActionPerformed

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSearchActionPerformed

    private void btnArchiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchiveActionPerformed
  int row = tblCompletedRepairs.getSelectedRow();

    if (row < 0) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a completed repair first."
        );
        return;
    }

    int repairId = Integer.parseInt(
        tblCompletedRepairs.getValueAt(row, 0).toString()
    );

    int confirm = JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to archive this completed repair?",
        "Confirm Archive",
        JOptionPane.YES_NO_OPTION
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    String sql =
        "UPDATE repairs " +
        "SET is_archived = 1 " +
        "WHERE repair_id = ?";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql)
    ) {

        pst.setInt(1, repairId);

        int updated = pst.executeUpdate();

        if (updated > 0) {

            JOptionPane.showMessageDialog(
                this,
                "Completed repair archived successfully!"
            );

            loadCompletedRepairs();

            clearRepairDetails();

        } else {

            JOptionPane.showMessageDialog(
                this,
                "Repair was not found."
            );
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error archiving repair:\n" + e.getMessage()
        );
    }
       // TODO add your handling code here:
    }//GEN-LAST:event_btnArchiveActionPerformed

    private void tblCompletedRepairsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblCompletedRepairsMouseClicked
    int row = tblCompletedRepairs.getSelectedRow();

    if (row < 0) {
        return;
    }

    int repairId = Integer.parseInt(
        tblCompletedRepairs.getValueAt(row, 0).toString()
    );

    String sql =
          "SELECT r.repair_id, " +
    "CONCAT(c.first_name, ' ', c.last_name) AS customer_name, " +
    "CONCAT(gt.gadget_type_name, ' - ', g.brand_model) AS gadget_name, " +
    "r.repair_description, " +
    "(SELECT GROUP_CONCAT(p.part_name ORDER BY p.part_name SEPARATOR ', ') " +
    " FROM parts p " +
    " WHERE FIND_IN_SET(CAST(p.part_id AS CHAR), r.parts_used) > 0) AS parts_used_names, " +
    "a.username AS technician_name, " +
    "r.date_brought, " +
    "r.date_returned, " +
    "r.repair_cost " +
    "FROM repairs r " +
    "JOIN gadgets g ON r.gadget_id = g.gadget_id " +
    "JOIN gadget_types gt ON g.gadget_type_id = gt.gadget_type_id " +
    "JOIN customers c ON g.customer_id = c.customer_id " +
    "LEFT JOIN technicians t ON r.technician_id = t.technician_id " +
    "LEFT JOIN accounts a ON t.account_id = a.account_id " +
    "WHERE r.repair_id = ?";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql)
    ) {

        pst.setInt(1, repairId);

        ResultSet rs = pst.executeQuery();

        if (rs.next()) {

            lblRepairId.setText(
                String.valueOf(rs.getInt("repair_id"))
            );

            lblCustomer.setText(
                rs.getString("customer_name")
            );

            lblGadget.setText(
                rs.getString("gadget_name")
            );

            lblTechnician.setText(
                rs.getString("technician_name")
                    
            );
            

          String problem = rs.getString("repair_description");
String partsUsed = rs.getString("parts_used_names");

txtProblem.setText(
    "Problem: " + (problem == null ? "-" : problem) +
    "\n\nParts Used: " + (partsUsed == null ? "None recorded" : partsUsed)
);

            lblDateBrought.setText(
                String.valueOf(rs.getDate("date_brought"))
            );

            if (rs.getDate("date_returned") != null) {
                cldrDateReturned.setDate(
                    rs.getDate("date_returned")
                );
            } else {
                cldrDateReturned.setDate(null);
            }

            if (rs.getObject("repair_cost") != null) {
                txtRepairCost.setText(
                    rs.getBigDecimal("repair_cost").toString()
                );
            } else {
                txtRepairCost.setText("");
            }
        }
                calculateRepairCost();


    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading repair details:\n" + e.getMessage()
        );
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_tblCompletedRepairsMouseClicked

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
  new DashboardFrame(username).setVisible(true);
    this.dispose();// TODO add your handling code here:
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
  String search = txtSearch.getText().trim();

    if (search.isEmpty()) {
        loadCompletedRepairs();
        return;
    }

    DefaultTableModel model =
        (DefaultTableModel) tblCompletedRepairs.getModel();

    model.setRowCount(0);

    String sql =
        "SELECT " +
        "r.repair_id, " +
        "CONCAT(c.first_name, ' ', c.last_name) AS customer_name, " +
        "CONCAT(gt.gadget_type_name, ' - ', g.brand_model) AS gadget_name, " +
        "r.repair_description, " +
         "(SELECT GROUP_CONCAT(p.part_name ORDER BY p.part_name SEPARATOR ', ') " +
         " FROM parts p " +" WHERE FIND_IN_SET(CAST(p.part_id AS CHAR), r.parts_used) > 0)"+ 
         " AS parts_used_names, " +
        "a.username AS technician_name, " +
        "r.date_brought " +
        "FROM repairs r " +
        "JOIN gadgets g ON r.gadget_id = g.gadget_id " +
        "JOIN gadget_types gt ON g.gadget_type_id = gt.gadget_type_id " +
        "JOIN customers c ON g.customer_id = c.customer_id " +
        "LEFT JOIN technicians t ON r.technician_id = t.technician_id " +
        "LEFT JOIN accounts a ON t.account_id = a.account_id " +
        "WHERE r.repair_status = 'Completed' " +
        "AND r.is_archived = 0 " +
        "AND (" +
        "CONCAT(c.first_name, ' ', c.last_name) LIKE ? OR " +
        "gt.gadget_type_name LIKE ? OR " +
        "g.brand_model LIKE ? OR " +
        "r.repair_description LIKE ?" +
        ") " +
        "ORDER BY r.repair_id DESC";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql)
    ) {
        String keyword = "%" + search + "%";

        pst.setString(1, keyword);
        pst.setString(2, keyword);
        pst.setString(3, keyword);
        pst.setString(4, keyword);

        try (ResultSet rs = pst.executeQuery()) {
            boolean found = false;

            while (rs.next()) {
                found = true;

                model.addRow(new Object[]{
                    rs.getInt("repair_id"),
                    rs.getString("customer_name"),
                    rs.getString("gadget_name"),
                    rs.getString("repair_description"),
                    rs.getString("technician_name"),
                    rs.getDate("date_brought"),
                    rs.getString("parts_used_names")
                });
            }

            if (!found) {
                JOptionPane.showMessageDialog(
                    this,
                    "No matching completed repair found."
                );

                loadCompletedRepairs();
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Error searching completed repairs:\n" + e.getMessage()
        );
    }
     // TODO add your handling code here:
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnSaveDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveDetailsActionPerformed
int row = tblCompletedRepairs.getSelectedRow();

    if (row == -1) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a completed repair first."
        );
        return;
    }

    int repairId = Integer.parseInt(
        tblCompletedRepairs.getValueAt(row, 0).toString()
    );

    if (cldrDateReturned.getDate() == null) {
        JOptionPane.showMessageDialog(
            this,
            "Please select the date returned."
        );
        return;
    }

    String costText = txtRepairCost.getText().trim();

    if (costText.isEmpty()) {
        JOptionPane.showMessageDialog(
            this,
            "Please enter the repair cost."
        );
        return;
    }

    double repairCost;

    try {
        repairCost = Double.parseDouble(costText);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(
            this,
            "Please enter a valid repair cost."
        );
        return;
    }

    java.sql.Date dateReturned =
        new java.sql.Date(
            cldrDateReturned.getDate().getTime()
        );

    String sql =
        "UPDATE repairs " +
        "SET date_returned = ?, repair_cost = ? " +
        "WHERE repair_id = ?";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql)
    ) {

        pst.setDate(1, dateReturned);
        pst.setDouble(2, repairCost);
        pst.setInt(3, repairId);

        int updated = pst.executeUpdate();

        if (updated > 0) {

            JOptionPane.showMessageDialog(
                this,
                "Repair details saved successfully!"
            );

            loadCompletedRepairs();

        } else {

            JOptionPane.showMessageDialog(
                this,
                "Repair not found."
            );
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error saving repair details:\n" + e.getMessage()
        );
    }    
    
    
    // TODO add your handling code here:
    }//GEN-LAST:event_btnSaveDetailsActionPerformed

    private void txtRepairCostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRepairCostActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRepairCostActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnArchive;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnGenerateReceipt;
    private javax.swing.JButton btnSaveDetails;
    private javax.swing.JButton btnSearch;
    private com.toedter.calendar.JDateChooser cldrDateReturned;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblCustomer;
    private javax.swing.JLabel lblDateBrought;
    private javax.swing.JLabel lblGadget;
    private javax.swing.JLabel lblRepairId;
    private javax.swing.JLabel lblTechnician;
    private javax.swing.JScrollPane scrollCompletedRepairs;
    private javax.swing.JTable tblCompletedRepairs;
    private javax.swing.JTextArea txtProblem;
    private javax.swing.JTextField txtRepairCost;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JLabel txtTitle;
    // End of variables declaration//GEN-END:variables
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gadgetrepair.frames.admin;
import gadgetrepair.frames.admin.AdminDashboardFrame;
import gadgetrepair.data.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class AccountManagementFrame extends javax.swing.JFrame {
    private String username;

    private void loadAccounts() {

  DefaultTableModel model =
        (DefaultTableModel) tblAccounts.getModel();

    model.setRowCount(0);

    String sql =
        "SELECT a.account_id, u.first_name, u.last_name, " +
        "a.username, a.role " +
        "FROM accounts a " +
        "LEFT JOIN users u ON a.account_id = u.account_id " +
        "WHERE a.is_active = 1 " +
        "ORDER BY a.account_id";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery()
    ) {

        while (rs.next()) {

            model.addRow(new Object[] {
                rs.getInt("account_id"),
                rs.getString("first_name"),
                rs.getString("last_name"),
                rs.getString("username"),
                rs.getString("role")
            });
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading accounts:\n" + e.getMessage()
        );
    }
}    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(AccountManagementFrame.class.getName());
private int selectedAccountId = -1;
    /**
     * Creates new form AccountManagementFrame
     */
    public AccountManagementFrame(String username) {
            this.username = username;


        initComponents();
            loadAccounts();
                    setLocationRelativeTo(null);



   
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtTitle = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtUserId = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtUsername = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnAdd = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        btnArchive = new javax.swing.JButton();
        btnClose = new javax.swing.JButton();
        txtPassword = new javax.swing.JPasswordField();
        chkShowPassword = new javax.swing.JCheckBox();
        cmbRole = new javax.swing.JComboBox<>();
        btnArchivedAccounts = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txtSearchAccount = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txtFirstName = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtLastName = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblAccounts = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 255, 51));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(18, 52, 86));
        jPanel1.setPreferredSize(new java.awt.Dimension(900, 80));

        txtTitle.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        txtTitle.setForeground(new java.awt.Color(242, 242, 242));
        txtTitle.setText("ACCOUNT MANAGEMENT");
        txtTitle.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\LOGO REPAIRsss.png")); // NOI18N
        jLabel8.setPreferredSize(new java.awt.Dimension(135, 135));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(535, Short.MAX_VALUE)
                .addComponent(txtTitle)
                .addGap(256, 256, 256)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(txtTitle)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1550, 116));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Account ID:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, -1, -1));

        txtUserId.setEditable(false);
        getContentPane().add(txtUserId, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 160, 190, 30));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel2.setText("Username:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 370, -1, -1));
        getContentPane().add(txtUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 370, 190, 40));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel3.setText("Password:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 450, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel4.setText("Role:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 520, -1, -1));

        btnAdd.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnAdd.setText("ADD ACCOUNT");
        btnAdd.addActionListener(this::btnAddActionPerformed);
        getContentPane().add(btnAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 580, 190, 40));

        btnEdit.setBackground(new java.awt.Color(24, 91, 160));
        btnEdit.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnEdit.setForeground(new java.awt.Color(255, 255, 255));
        btnEdit.setText("EDIT");
        btnEdit.addActionListener(this::btnEditActionPerformed);
        getContentPane().add(btnEdit, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 680, -1, -1));

        btnSave.setBackground(new java.awt.Color(24, 91, 160));
        btnSave.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnSave.setForeground(new java.awt.Color(255, 255, 255));
        btnSave.setText("SAVE");
        btnSave.addActionListener(this::btnSaveActionPerformed);
        getContentPane().add(btnSave, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 680, -1, -1));

        btnArchive.setBackground(new java.awt.Color(24, 91, 160));
        btnArchive.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnArchive.setForeground(new java.awt.Color(255, 255, 255));
        btnArchive.setText("ARCHIVE");
        btnArchive.addActionListener(this::btnArchiveActionPerformed);
        getContentPane().add(btnArchive, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 680, -1, -1));

        btnClose.setBackground(new java.awt.Color(24, 91, 160));
        btnClose.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnClose.setForeground(new java.awt.Color(255, 255, 255));
        btnClose.setText("CLOSE");
        btnClose.addActionListener(this::btnCloseActionPerformed);
        getContentPane().add(btnClose, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 750, -1, -1));
        getContentPane().add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 450, 190, 40));

        chkShowPassword.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        chkShowPassword.setText("Show Password");
        chkShowPassword.addActionListener(this::chkShowPasswordActionPerformed);
        getContentPane().add(chkShowPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 450, -1, -1));

        cmbRole.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cmbRole.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Role", "Staff", "Technician", "Admin", " " }));
        cmbRole.addActionListener(this::cmbRoleActionPerformed);
        getContentPane().add(cmbRole, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 520, 190, 40));

        btnArchivedAccounts.setBackground(new java.awt.Color(24, 91, 160));
        btnArchivedAccounts.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnArchivedAccounts.setForeground(new java.awt.Color(255, 255, 255));
        btnArchivedAccounts.setText("ARCHIVED ACCOUNT");
        btnArchivedAccounts.addActionListener(this::btnArchivedAccountsActionPerformed);
        getContentPane().add(btnArchivedAccounts, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 750, 270, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel7.setText("Search:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 160, -1, -1));
        getContentPane().add(txtSearchAccount, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 160, 130, 40));

        btnSearch.setBackground(new java.awt.Color(24, 91, 160));
        btnSearch.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setText("Search");
        btnSearch.addActionListener(this::btnSearchActionPerformed);
        getContentPane().add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 160, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel5.setText("First Name:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, -1, -1));
        getContentPane().add(txtFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, 190, 40));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel6.setText("Last Name:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 300, -1, -1));
        getContentPane().add(txtLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 300, 190, 40));

        tblAccounts.setBackground(new java.awt.Color(15, 43, 77));
        tblAccounts.setForeground(new java.awt.Color(255, 255, 255));
        tblAccounts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Account ID", "First Name", "Last Name", "Username", "Role"
            }
        ));
        jScrollPane1.setViewportView(tblAccounts);

        jScrollPane2.setViewportView(jScrollPane1);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 220, 890, 450));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed

    new AdminDashboardFrame(username).setVisible(true);
    this.dispose();      // TODO add your handling code here:
    }//GEN-LAST:event_btnCloseActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed

    String firstName = txtFirstName.getText().trim();
    String lastName = txtLastName.getText().trim();
    String username = txtUsername.getText().trim();
    String password = new String(txtPassword.getPassword());
    String role = cmbRole.getSelectedItem().toString();

    if (firstName.isEmpty() ||
        lastName.isEmpty() ||   
        username.isEmpty() ||
        password.isEmpty() ||
        cmbRole.getSelectedIndex() == 0) {

        JOptionPane.showMessageDialog(
            this,
            "Please complete all fields."
        );
        return;
    }

    if (!firstName.matches("[a-zA-ZÀ-ÿ' -]+")) {

        JOptionPane.showMessageDialog(
            this,
            "First name must contain letters only."
        );
        return;
    }

    if (!lastName.matches("[a-zA-ZÀ-ÿ' -]+")) {

        JOptionPane.showMessageDialog(
            this,
            "Last name must contain letters only."
        );
        return;
    }

    String accountSQL =
        "INSERT INTO accounts " +
        "(username, password, role, is_first_login, is_active) " +
        "VALUES (?, ?, ?, 1, 1)";

    String userSQL =
        "INSERT INTO users " +
        "(account_id, first_name, last_name) " +
        "VALUES (?, ?, ?)";

    String technicianSQL =
        "INSERT INTO technicians (account_id) " +
        "VALUES (?)";

    Connection conn = null;

    try {

        conn = DatabaseConnection.getConnection();
        conn.setAutoCommit(false);

        int accountId;

        // =========================
        // INSERT ACCOUNT
        // =========================
        try (
            PreparedStatement pst =
                conn.prepareStatement(
                    accountSQL,
                    java.sql.Statement.RETURN_GENERATED_KEYS
                )
        ) {

            pst.setString(1, username);
            pst.setString(2, password);
            pst.setString(3, role);

            pst.executeUpdate();

            try (ResultSet rs = pst.getGeneratedKeys()) {

                if (!rs.next()) {
                    throw new SQLException(
                        "Could not get the generated Account ID."
                    );
                }

                accountId = rs.getInt(1);
            }
        }

        // =========================
        // INSERT USER
        // =========================
        try (
            PreparedStatement pst =
                conn.prepareStatement(userSQL)
        ) {

            pst.setInt(1, accountId);
            pst.setString(2, firstName);
            pst.setString(3, lastName);

            pst.executeUpdate();
        }

        // =========================
        // INSERT TECHNICIAN
        // ONLY IF ROLE = TECHNICIAN
        // =========================
        if (role.equalsIgnoreCase("Technician")) {

            try (
                PreparedStatement pst =
                    conn.prepareStatement(technicianSQL)
            ) {

                pst.setInt(1, accountId);

                pst.executeUpdate();
            }
        }

        // =========================
        // SAVE EVERYTHING
        // =========================
        conn.commit();

        JOptionPane.showMessageDialog(
            this,
            "Account created successfully!"
        );

        loadAccounts();

        // Clear fields
        txtUserId.setText("");
        txtFirstName.setText("");
        txtLastName.setText("");
        txtUsername.setText("");
        txtPassword.setText("");
        cmbRole.setSelectedIndex(0);

    } catch (SQLException e) {

        // Undo everything if something failed
        try {
            if (conn != null) {
                conn.rollback();
            }
        } catch (SQLException rollbackError) {
            rollbackError.printStackTrace();
        }

        if (e.getMessage() != null &&
            e.getMessage().toLowerCase().contains("duplicate")) {

            JOptionPane.showMessageDialog(
                this,
                "Username already exists."
            );

        } else {

            JOptionPane.showMessageDialog(
                this,
                "Error creating account:\n" +
                e.getMessage()
            );
        }

    } finally {

        try {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

  // TODO add your handling code here:

    }//GEN-LAST:event_btnAddActionPerformed

    private void chkShowPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkShowPasswordActionPerformed
if (chkShowPassword.isSelected()) {
    txtPassword.setEchoChar((char) 0);
} else {
    txtPassword.setEchoChar('•');
}
    
    // TODO add your handling code here:
    }//GEN-LAST:event_chkShowPasswordActionPerformed

    private void cmbRoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbRoleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbRoleActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed

    if (selectedAccountId == -1) {

        JOptionPane.showMessageDialog(
            this,
            "Please click EDIT first."
        );
        return;
    }

    String firstName = txtFirstName.getText().trim();
    String lastName = txtLastName.getText().trim();
    String username = txtUsername.getText().trim();
    String password = new String(txtPassword.getPassword()).trim();

    if (firstName.isEmpty() || lastName.isEmpty()) {

        JOptionPane.showMessageDialog(
            this,
            "First name and last name cannot be empty."
        );
        return;
    }

    if (username.isEmpty()) {

        JOptionPane.showMessageDialog(
            this,
            "Username cannot be empty."
        );
        return;
    }

    if (!firstName.matches("[a-zA-ZÀ-ÿ' -]+")) {

        JOptionPane.showMessageDialog(
            this,
            "First name must contain letters only."
        );
        return;
    }

    if (!lastName.matches("[a-zA-ZÀ-ÿ' -]+")) {

        JOptionPane.showMessageDialog(
            this,
            "Last name must contain letters only."
        );
        return;
    }

    if (cmbRole.getSelectedIndex() == 0) {

        JOptionPane.showMessageDialog(
            this,
            "Please select a role."
        );
        return;
    }

    String role = cmbRole.getSelectedItem().toString();

    String accountSQL;

    if (password.isEmpty()) {

        accountSQL =
            "UPDATE accounts " +
            "SET username = ?, role = ? " +
            "WHERE account_id = ?";

    } else {

        accountSQL =
            "UPDATE accounts " +
            "SET username = ?, password = ?, role = ? " +
            "WHERE account_id = ?";
    }

    String userSQL =
        "UPDATE users " +
        "SET first_name = ?, last_name = ? " +
        "WHERE account_id = ?";

    Connection conn = null;

    try {

        conn = DatabaseConnection.getConnection();
        conn.setAutoCommit(false);

        // -------------------------
        // UPDATE ACCOUNTS
        // -------------------------

        try (PreparedStatement pst =
                 conn.prepareStatement(accountSQL)) {

            if (password.isEmpty()) {

                pst.setString(1, username);
                pst.setString(2, role);
                pst.setInt(3, selectedAccountId);

            } else {

                pst.setString(1, username);
                pst.setString(2, password);
                pst.setString(3, role);
                pst.setInt(4, selectedAccountId);
            }

            pst.executeUpdate();
        }

        // -------------------------
        // UPDATE USERS
        // -------------------------

        try (PreparedStatement pst =
                 conn.prepareStatement(userSQL)) {

            pst.setString(1, firstName);
            pst.setString(2, lastName);
            pst.setInt(3, selectedAccountId);

            pst.executeUpdate();
        }

        conn.commit();

        JOptionPane.showMessageDialog(
            this,
            "Account updated successfully!"
        );

        loadAccounts();

        txtUserId.setText("");
        txtFirstName.setText("");
        txtLastName.setText("");
        txtUsername.setText("");
        txtPassword.setText("");
        cmbRole.setSelectedIndex(0);

        selectedAccountId = -1;

    } catch (SQLException e) {

        try {
            if (conn != null) {
                conn.rollback();
            }
        } catch (SQLException rollbackError) {
            rollbackError.printStackTrace();
        }

        if (e.getMessage() != null &&
            e.getMessage().toLowerCase().contains("duplicate")) {

            JOptionPane.showMessageDialog(
                this,
                "Username already exists."
            );

        } else {

            JOptionPane.showMessageDialog(
                this,
                "Error updating account:\n" + e.getMessage()
            );
        }

    } finally {

        try {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

        // TODO add your handling code here:
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed


    int row = tblAccounts.getSelectedRow();

    if (row < 0) {

        JOptionPane.showMessageDialog(
            this,
            "Please select an account to edit."
        );
        return;
    }

    selectedAccountId = Integer.parseInt(
        tblAccounts.getValueAt(row, 0).toString()
    );

    txtUserId.setText(
        tblAccounts.getValueAt(row, 0).toString()
    );

    txtFirstName.setText(
        tblAccounts.getValueAt(row, 1).toString()
    );

    txtLastName.setText(
        tblAccounts.getValueAt(row, 2).toString()
    );

    txtUsername.setText(
        tblAccounts.getValueAt(row, 3).toString()
    );

    cmbRole.setSelectedItem(
        tblAccounts.getValueAt(row, 4).toString()
    );

    txtPassword.setText("");

    JOptionPane.showMessageDialog(
        this,
        "Account selected. You can now edit it."
    );



    // TODO add your handling code here:

    }//GEN-LAST:event_btnEditActionPerformed

    private void btnArchiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchiveActionPerformed
 
    int row = tblAccounts.getSelectedRow();

    if (row == -1) {
        JOptionPane.showMessageDialog(
            this,
            "Please select an account first."
        );
        return;
    }

    int accountId = Integer.parseInt(
        tblAccounts.getValueAt(row, 0).toString()
    );

    String username = tblAccounts.getValueAt(row, 3).toString();

    int confirm = JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to archive account '" + username + "'?",
        "Archive Account",
        JOptionPane.YES_NO_OPTION
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    String sql =
        "UPDATE accounts SET is_active = 0 " +
        "WHERE account_id = ?";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql)
    ) {

        pst.setInt(1, accountId);

        pst.executeUpdate();

        JOptionPane.showMessageDialog(
            this,
            "Account archived successfully!"
        );

        // Refresh active accounts
        loadAccounts();

        // Clear fields
        txtUserId.setText("");
        txtUsername.setText("");
        txtPassword.setText("");
        cmbRole.setSelectedIndex(0);

        // Reset selected account
        selectedAccountId = -1;

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error archiving account:\n" + e.getMessage()
        );
    }


        // TODO add your handling code here:
    }//GEN-LAST:event_btnArchiveActionPerformed

    private void btnArchivedAccountsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchivedAccountsActionPerformed
    new ArchivedAccountsFrame(username).setVisible(true);
    this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_btnArchivedAccountsActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
    String search = txtSearchAccount.getText().trim();
    if (search.isEmpty()) {
         loadAccounts();
        return;
    }

    DefaultTableModel model =
        (DefaultTableModel) tblAccounts.getModel();

    model.setRowCount(0);

 String sql =
    "SELECT a.account_id, u.first_name, u.last_name, " +
    "a.username, a.role " +
    "FROM accounts a " +
    "LEFT JOIN users u ON a.account_id = u.account_id " +
    "WHERE a.is_active = 1 " +
    "AND (" +
    "CAST(a.account_id AS CHAR) LIKE ? OR " +
    "u.first_name LIKE ? OR " +
    "u.last_name LIKE ? OR " +
    "a.username LIKE ? OR " +
    "a.role LIKE ?" +
    ") " +
    "ORDER BY a.account_id";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql)
    ) {

        String value = "%" + search + "%";

        pst.setString(1, value);
        pst.setString(2, value);
        pst.setString(3, value);
        pst.setString(4, value);
        pst.setString(5, value);

        try (ResultSet rs = pst.executeQuery()) {

            boolean found = false;

            while (rs.next()) {

                found = true;

                model.addRow(new Object[] {
                    rs.getInt("account_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("username"),
                    rs.getString("role")
                });
            }

            if (!found) {

                JOptionPane.showMessageDialog(
                    this,
                    "No matching account found."
                );

                loadAccounts ();
            }
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error searching accounts:\n" + e.getMessage()
        );
    }
     // TODO add your handling code here:
    }//GEN-LAST:event_btnSearchActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnArchive;
    private javax.swing.JButton btnArchivedAccounts;
    private javax.swing.JButton btnClose;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnSearch;
    private javax.swing.JCheckBox chkShowPassword;
    private javax.swing.JComboBox<String> cmbRole;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblAccounts;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtLastName;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtSearchAccount;
    private javax.swing.JLabel txtTitle;
    private javax.swing.JTextField txtUserId;
    private javax.swing.JTextField txtUsername;
    // End of variables declaration//GEN-END:variables
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gadgetrepair.frames.technician;
import javax.swing.JOptionPane;
import gadgetrepair.data.DatabaseConnection;
import gadgetrepair.frames.Loginframee;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class TechnicianDashboard extends javax.swing.JFrame {
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(TechnicianDashboard.class.getName());
private int technicianId;
private String technicianUsername;

private int selectedRepairId = -1;

private javax.swing.DefaultListModel<String> availablePartsModel =
        new javax.swing.DefaultListModel<>();
private final java.util.Set<Integer> selectedPartIndexes =
        new java.util.LinkedHashSet<>();

   private void loadRepairs() {

    String sql =
         "SELECT " +
    "r.repair_id, " +
    "CONCAT(c.first_name, ' ', c.last_name) AS customer, " +
    "CONCAT(g.brand_model, ' - ', gt.gadget_type_name) AS gadget, " +
    "r.repair_description AS problem, " +
    "a.username AS technician, " +
    "r.date_brought, " +
"r.repair_status, " +
"(SELECT GROUP_CONCAT(p.part_name ORDER BY p.part_name SEPARATOR ', ') " +
" FROM parts p " +
" WHERE FIND_IN_SET(CAST(p.part_id AS CHAR), r.parts_used) > 0) AS parts_used_names " +
"FROM repairs r " +
    "JOIN gadgets g ON r.gadget_id = g.gadget_id " +
    "JOIN gadget_types gt ON g.gadget_type_id = gt.gadget_type_id " +
    "JOIN customers c ON g.customer_id = c.customer_id " +
    "LEFT JOIN technicians t ON r.technician_id = t.technician_id " +
    "LEFT JOIN accounts a ON t.account_id = a.account_id " +
    "WHERE r.technician_id = ? " +
    "AND r.is_archived = 0 " +
    "AND r.repair_status <> 'Completed'";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql)
    ) {

        pst.setInt(1, technicianId);

        try (ResultSet rs = pst.executeQuery()) {

            DefaultTableModel model =
                (DefaultTableModel) tblRepairs.getModel();

            model.setRowCount(0);

            while (rs.next()) {

                model.addRow(new Object[]{
                    rs.getInt("repair_id"),
                    rs.getString("customer"),
                    rs.getString("gadget"),
                    rs.getString("problem"),
                    rs.getString("technician"),
                    rs.getDate("date_brought"),
                    rs.getString("repair_status"),
                    rs.getString("parts_used_names")
                });
            }
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading repairs:\n" + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
   
   private void loadAvailableParts() {
    availablePartsModel.clear();

    if (selectedRepairId == -1) {
        return;
    }

    String sql =
        "SELECT p.part_id, p.part_name " +
        "FROM repairs r " +
        "JOIN gadgets g ON r.gadget_id = g.gadget_id " +
        "JOIN parts p ON p.gadget_type_id = g.gadget_type_id " +
        "WHERE r.repair_id = ? " +
        "AND r.technician_id = ? " +
        "AND r.is_archived = 0 " +
        "AND p.is_active = 1 " +
        "ORDER BY p.part_name";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql)
    ) {
        pst.setInt(1, selectedRepairId);
        pst.setInt(2, technicianId);

        try (ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                availablePartsModel.addElement(
                    rs.getInt("part_id") + " - " +
                    rs.getString("part_name")
                );
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Error loading available parts:\n" + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}

public TechnicianDashboard(int technicianId, String technicianUsername) {

    initComponents();

    this.technicianId = technicianId;
    this.technicianUsername = technicianUsername;

    setLocationRelativeTo(null);
    
    listAvailableParts.setModel(availablePartsModel);

listAvailableParts.setSelectionMode(
    javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION
);
    lblGreeting.setText("Hello, " + technicianUsername);

    tblRepairs.setModel(new DefaultTableModel(
        new Object[][] {},
        new String[] {
           "Repair ID",
    "Customer",
    "Gadget",
    "Problem",
    "Repair Technician",
    "Date Brought",
    "Status",
    "Parts Used"
        }
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    });

    cmbStatus.setSelectedIndex(0);

    loadRepairs();
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        txtTitle = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblRepairs = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        txtSearchRepair = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        Technician1 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        Technician2 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        cmbStatus = new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        lblGreeting = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        listAvailableParts = new javax.swing.JList<>();
        jLabel2 = new javax.swing.JLabel();
        txtPartQuantity = new javax.swing.JTextField();
        btnSaveParts = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(248, 250, 252));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(18, 52, 86));
        jPanel2.setPreferredSize(new java.awt.Dimension(850, 80));

        txtTitle.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        txtTitle.setForeground(new java.awt.Color(255, 255, 255));
        txtTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtTitle.setText("TECHNICIAN MENU");

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\LOGO REPAIRsss.png")); // NOI18N
        jLabel1.setPreferredSize(new java.awt.Dimension(135, 135));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(541, Short.MAX_VALUE)
                .addComponent(txtTitle)
                .addGap(335, 335, 335)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(txtTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1520, 115));

        jButton2.setBackground(new java.awt.Color(220, 53, 69));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("LOGOUT");
        jButton2.setPreferredSize(new java.awt.Dimension(110, 38));
        jButton2.addActionListener(this::jButton2ActionPerformed);
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 150, -1, -1));

        tblRepairs.setBackground(new java.awt.Color(15, 43, 77));
        tblRepairs.setForeground(new java.awt.Color(255, 255, 255));
        tblRepairs.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "REPAIR ID", "CUSTOMER", "GADGET", "PROBLEM", "REPAIR TECHNICIAN", "DATE BROUGHT", "Status"
            }
        ));
        tblRepairs.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblRepairsMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblRepairs);

        jScrollPane2.setViewportView(jScrollPane1);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 220, 970, 380));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel5.setText("SEARCH REPAIR:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 160, -1, -1));

        txtSearchRepair.addActionListener(this::txtSearchRepairActionPerformed);
        getContentPane().add(txtSearchRepair, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 160, 160, 30));

        btnSearch.setBackground(new java.awt.Color(15, 43, 77));
        btnSearch.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setText("SEARCH");
        btnSearch.addActionListener(this::btnSearchActionPerformed);
        getContentPane().add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 160, -1, 30));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel4.setText("Repair ID:");

        jLabel6.setBackground(new java.awt.Color(0, 153, 204));
        jLabel6.setText("-");
        jLabel6.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel7.setText("Customer");

        jLabel8.setText("-");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel9.setText("Gadget");

        jLabel10.setText("-");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel11.setText("Problem:");

        jTextArea2.setEditable(false);
        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane3.setViewportView(jTextArea2);

        Technician1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Technician1.setText("Repair Technician:");

        jLabel15.setText("-");

        Technician2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Technician2.setText("Date Brought");

        jLabel16.setText("-");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel13.setText("Status:");

        cmbStatus.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cmbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Status", "Pending", "In Progress", "Completed" }));
        cmbStatus.addActionListener(this::cmbStatusActionPerformed);

        jButton3.setBackground(new java.awt.Color(24, 91, 160));
        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("SAVE STATUS");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(20, 20, 20)
                            .addComponent(jLabel4)
                            .addGap(8, 8, 8)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(20, 20, 20)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addComponent(jLabel9)
                                    .addGap(32, 32, 32)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addComponent(jLabel7)
                                    .addGap(7, 7, 7)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(Technician1)
                            .addGap(10, 10, 10)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(20, 20, 20)
                            .addComponent(jLabel11)
                            .addGap(18, 18, 18)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(Technician2)
                            .addGap(18, 18, 18)
                            .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jLabel13)
                            .addGap(18, 18, 18)
                            .addComponent(cmbStatus, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(128, 128, 128)
                        .addComponent(jButton3)))
                .addGap(163, 163, 163))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel9))
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel11)
                        .addGap(81, 81, 81))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Technician1)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Technician2)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmbStatus))
                .addGap(18, 18, 18)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, 400, 520));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(18, 52, 86));
        jLabel3.setText("REPAIR DETAILS");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 190, -1, -1));

        lblGreeting.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblGreeting.setText("---");
        getContentPane().add(lblGreeting, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 170, -1));

        listAvailableParts.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        listAvailableParts.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        listAvailableParts.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                listAvailablePartsMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(listAvailableParts);

        getContentPane().add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 610, 160, 70));

        jLabel2.setText("Quantity");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 720, -1, -1));

        txtPartQuantity.setText("jTextField1");
        getContentPane().add(txtPartQuantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 720, -1, -1));

        btnSaveParts.setText("SAVE PARTS");
        btnSaveParts.addActionListener(this::btnSavePartsActionPerformed);
        getContentPane().add(btnSaveParts, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 720, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
int confirm = JOptionPane.showConfirmDialog(
    this,
    "Are you sure you want to logout?",
    "Confirm Logout",
    JOptionPane.YES_NO_OPTION
);

if (confirm == JOptionPane.YES_OPTION) {
    new Loginframee().setVisible(true);
    this.dispose();
}            // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtSearchRepairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchRepairActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSearchRepairActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
if (selectedRepairId == -1) {
    JOptionPane.showMessageDialog(
        this,
        "Please select a repair first."
    );
    return;
}

int repairId = selectedRepairId;

if (cmbStatus.getSelectedIndex() <= 0) {
    JOptionPane.showMessageDialog(
        this,
        "Please select a status."
    );
    return;
}

   

    String status =
        cmbStatus.getSelectedItem().toString();

   String sql =
    "UPDATE repairs " +
    "SET repair_status = ? " +
    "WHERE repair_id = ? " +
    "AND technician_id = ? " +
    "AND is_archived = 0";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql)
    ) {

           pst.setString(1, status);
           pst.setInt(2, repairId);
           pst.setInt(3, technicianId);

        int updated = pst.executeUpdate();

        if (updated > 0) {

            JOptionPane.showMessageDialog(
                this,
                "Repair status updated successfully!"
            );

            loadRepairs();

            jLabel6.setText("-");
            jLabel8.setText("-");
            jLabel10.setText("-");
            jTextArea2.setText("-");
            jLabel15.setText("-");
            jLabel16.setText("-");
            cmbStatus.setSelectedIndex(0);

        } else {

            JOptionPane.showMessageDialog(
                this,
                "No repair was updated."
            );
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error updating repair status:\n" + e.getMessage()
        );
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void tblRepairsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblRepairsMouseClicked
      int row = tblRepairs.getSelectedRow();

    if (row < 0) {
        return;
    }

    jLabel6.setText(
        tblRepairs.getValueAt(row, 0).toString()
    );

    jLabel8.setText(
        tblRepairs.getValueAt(row, 1).toString()
    );

    jLabel10.setText(
        tblRepairs.getValueAt(row, 2).toString()
    );

    jTextArea2.setText(
        tblRepairs.getValueAt(row, 3).toString()
    );

    jLabel15.setText(
        tblRepairs.getValueAt(row, 4).toString()
    );

    jLabel16.setText(
        tblRepairs.getValueAt(row, 5).toString()
    );

    cmbStatus.setSelectedItem(
        tblRepairs.getValueAt(row, 6).toString()
    );
    
    selectedRepairId = Integer.parseInt(
    tblRepairs.getValueAt(row, 0).toString()
);

loadAvailableParts();
    // TODO add your handling code here:
    }//GEN-LAST:event_tblRepairsMouseClicked

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
  String keyword = txtSearchRepair.getText().trim();

    if (keyword.isEmpty()) {
        loadRepairs();
        return;
    }

    String sql =
        "SELECT r.repair_id, " +
        "CONCAT(c.first_name, ' ', c.last_name) AS customer, " +
        "CONCAT(g.brand_model, ' - ', gt.gadget_type_name) AS gadget, " +
        "r.repair_description AS problem, " +
        "a.username AS technician, " +
        "r.date_brought, " +
"r.repair_status, " +
"(SELECT GROUP_CONCAT(p.part_name ORDER BY p.part_name SEPARATOR ', ') " +
" FROM parts p " +
" WHERE FIND_IN_SET(CAST(p.part_id AS CHAR), r.parts_used) > 0) AS parts_used_names " +
"FROM repairs r " +
        "JOIN gadgets g ON r.gadget_id = g.gadget_id " +
        "JOIN gadget_types gt ON g.gadget_type_id = gt.gadget_type_id " +
        "JOIN customers c ON g.customer_id = c.customer_id " +
        "LEFT JOIN technicians t ON r.technician_id = t.technician_id " +
        "LEFT JOIN accounts a ON t.account_id = a.account_id " +
        "WHERE r.technician_id = ? " +
        "AND r.is_archived = 0 " +
        "AND r.repair_status <> 'Completed' " +
        "AND (" +
        "CAST(r.repair_id AS CHAR) LIKE ? " +
        "OR CONCAT(c.first_name, ' ', c.last_name) LIKE ? " +
        "OR g.brand_model LIKE ? " +
        "OR gt.gadget_type_name LIKE ?" +
        ")";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql)
    ) {
        String search = "%" + keyword + "%";

        pst.setInt(1, technicianId);
        pst.setString(2, search);
        pst.setString(3, search);
        pst.setString(4, search);
        pst.setString(5, search);

        try (ResultSet rs = pst.executeQuery()) {
            DefaultTableModel model =
                (DefaultTableModel) tblRepairs.getModel();

            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("repair_id"),
                    rs.getString("customer"),
                    rs.getString("gadget"),
                    rs.getString("problem"),
                    rs.getString("technician"),
                    rs.getDate("date_brought"),
                    rs.getString("repair_status"),
                    rs.getString("parts_used_names")
                });
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Error searching repairs:\n" + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
// TODO add your handling code here:
    }//GEN-LAST:event_btnSearchActionPerformed

    private void cmbStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbStatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbStatusActionPerformed

    private void btnSavePartsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSavePartsActionPerformed

    if (selectedRepairId == -1) {
        JOptionPane.showMessageDialog(this, "Please select a repair first.");
        return;
    }

    java.util.List<String> selectedParts = new java.util.ArrayList<>();

    for (int index : selectedPartIndexes) {
        if (index >= 0 && index < listAvailableParts.getModel().getSize()) {
            selectedParts.add(
                listAvailableParts.getModel().getElementAt(index)
            );
        }
    }

    if (selectedParts.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please select at least one part.");
        return;
    }

    StringBuilder partIds = new StringBuilder();

    for (String part : selectedParts) {
        String partId = part.split(" - ", 2)[0].trim();

        if (partIds.length() > 0) {
            partIds.append(",");
        }

        partIds.append(partId);
    }

    String sql = "UPDATE repairs SET parts_used = ? "
               + "WHERE repair_id = ? AND technician_id = ? "
               + "AND is_archived = 0";

    try (
        java.sql.Connection conn = DatabaseConnection.getConnection();
        java.sql.PreparedStatement pst = conn.prepareStatement(sql)
    ) {
        pst.setString(1, partIds.toString());
        pst.setInt(2, selectedRepairId);
        pst.setInt(3, technicianId);

        int rowsUpdated = pst.executeUpdate();

        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(this, "Parts saved successfully!");

            selectedPartIndexes.clear();
            listAvailableParts.clearSelection();

            loadRepairs();
        } else {
            JOptionPane.showMessageDialog(
                this,
                "Unable to save parts for this repair."
            );
        }

    } catch (java.sql.SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Error saving parts: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }       // TODO add your handling code here:
    }//GEN-LAST:event_btnSavePartsActionPerformed

    private void listAvailablePartsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listAvailablePartsMouseClicked

     int index = listAvailableParts.locationToIndex(evt.getPoint());

    if (index < 0) {
        return;
    }

    java.awt.Rectangle bounds =
            listAvailableParts.getCellBounds(index, index);

    if (bounds == null || !bounds.contains(evt.getPoint())) {
        return;
    }

    if (selectedPartIndexes.contains(index)) {
        selectedPartIndexes.remove(index);
    } else {
        selectedPartIndexes.add(index);
    }

    listAvailableParts.setSelectedIndices(
            selectedPartIndexes.stream()
                    .mapToInt(Integer::intValue)
                    .toArray()
    );    // TODO add your handling code here:
    }//GEN-LAST:event_listAvailablePartsMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Technician1;
    private javax.swing.JLabel Technician2;
    private javax.swing.JButton btnSaveParts;
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox<String> cmbStatus;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JLabel lblGreeting;
    private javax.swing.JList<String> listAvailableParts;
    private javax.swing.JTable tblRepairs;
    private javax.swing.JTextField txtPartQuantity;
    private javax.swing.JTextField txtSearchRepair;
    private javax.swing.JLabel txtTitle;
    // End of variables declaration//GEN-END:variables
}

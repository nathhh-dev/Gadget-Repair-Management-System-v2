
package gadgetrepair.frames.staff;
import gadgetrepair.frames.staff.DashboardFrame;
import gadgetrepair.data.DatabaseConnection;
import gadgetrepair.frames.admin.AdminDashboardFrame;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import javax.swing.DefaultListModel;
import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import java.awt.Component;
import java.util.HashSet;
import java.util.Set;

public class GadgetFrame extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(GadgetFrame.class.getName());

    private String userRole;
    private String username;
    private boolean editMode = false;
    private final Set<String> checkedIssues = new HashSet<>();
    
    private int getOrCreateGadgetTypeId(String gadgetType) throws SQLException {

    String findSql =
        "SELECT gadget_type_id " +
        "FROM gadget_types " +
        "WHERE gadget_type_name = ?";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(findSql)
    ) {

        pst.setString(1, gadgetType);

        try (ResultSet rs = pst.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("gadget_type_id");
            }
        }
    }

    String insertSql =
        "INSERT INTO gadget_types (gadget_type_name) " +
        "VALUES (?)";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst =
            conn.prepareStatement(
                insertSql,
                java.sql.Statement.RETURN_GENERATED_KEYS
            )
    ) {

        pst.setString(1, gadgetType);

        pst.executeUpdate();

        try (ResultSet rs =
                 pst.getGeneratedKeys()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        }
    }

    throw new SQLException(
        "Unable to create gadget type."
    );
}
    
    private void setGadgetColumnWidths() {
    javax.swing.table.TableColumnModel columns =
            tblGadgets.getColumnModel();

     columns.getColumn(0).setPreferredWidth(75);  
    columns.getColumn(1).setPreferredWidth(95);  
    columns.getColumn(2).setPreferredWidth(140); 
    columns.getColumn(3).setPreferredWidth(190); 
    columns.getColumn(4).setPreferredWidth(300);
}
    
    private void loadCustomerInformation(int customerId) {

    String sql =
        "SELECT first_name, last_name, contact_number " +
        "FROM customers " +
        "WHERE customer_id = ? " +
        "AND is_active = 1";

    try (
        Connection conn =
            DatabaseConnection.getConnection();
        PreparedStatement pst =
            conn.prepareStatement(sql)
    ) {

        pst.setInt(1, customerId);

        try (ResultSet rs =
                 pst.executeQuery()) {

            if (rs.next()) {

                String firstName =
                    rs.getString("first_name");

                String lastName =
                    rs.getString("last_name");

                String contact =
                    rs.getString("contact_number");

                txtSelectedCustomerId.setText(
                    String.valueOf(customerId)
                );

                txtSelectedCustomerName.setText(
                    firstName + " " + lastName
                );

                txtSelectedContact.setText(contact);
            }
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading customer:\n"
            + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
    
    private void loadIssuesByGadgetType() {
        
        checkedIssues.clear();

     javax.swing.DefaultListModel<String> model =
        new javax.swing.DefaultListModel<>();

    String gadgetType =
        cmbGadgetType.getSelectedItem() == null
        ? ""
        : cmbGadgetType.getSelectedItem().toString();

    switch (gadgetType) {

        case "Mobile Phone":
            model.addElement("Screen/Display");
            model.addElement("Battery");
            model.addElement("Charging Port");
            model.addElement("Camera");
            model.addElement("Speaker/Microphone");
            model.addElement("Software");
            model.addElement("Other");
            break;

        case "Tablet":
            model.addElement("Screen/Display");
            model.addElement("Battery");
            model.addElement("Charging Port");
            model.addElement("Camera");
            model.addElement("Speaker");
            model.addElement("Software");
            model.addElement("Other");
            break;

        case "Laptop":
            model.addElement("Screen/Display");
            model.addElement("Battery");
            model.addElement("Keyboard");
            model.addElement("Charging Port");
            model.addElement("Overheating");
            model.addElement("Software");
            model.addElement("Other");
            break;

        case "Desktop Computer":
            model.addElement("Power Problem");
            model.addElement("No Display");
            model.addElement("Overheating");
            model.addElement("Operating System");
            model.addElement("Hardware Problem");
            model.addElement("Other");
            break;

        case "Smartwatch":
            model.addElement("Screen/Display");
            model.addElement("Battery");
            model.addElement("Charging Problem");
            model.addElement("Software");
            model.addElement("Other");
            break;

        case "Game Console":
            model.addElement("HDMI Port");
            model.addElement("Power Problem");
            model.addElement("Overheating");
            model.addElement("Controller Problem");
            model.addElement("Disc/Drive Problem");
            model.addElement("Software");
            model.addElement("Other");
            break;

        case "Other":
            model.addElement("Other");
            break;
    }

    lstIssues.setModel(model);

   lstIssues.clearSelection();
lstIssues.repaint();

lblOtherIssue.setVisible(false);
txtOtherIssue.setVisible(false);
txtOtherIssue.setText("");
}
    
    private void setupIssueCheckboxes() {
    lstIssues.setSelectionMode(
        javax.swing.ListSelectionModel.SINGLE_SELECTION
    );

    lstIssues.setCellRenderer(new ListCellRenderer<String>() {
        @Override
        public Component getListCellRendererComponent(
                JList<? extends String> list,
                String value,
                int index,
                boolean selected,
                boolean focus) {

            JCheckBox box = new JCheckBox(value);
            box.setSelected(checkedIssues.contains(value));
            box.setOpaque(true);

            box.setBackground(
                selected ? list.getSelectionBackground()
                         : list.getBackground()
            );

            box.setForeground(
                selected ? list.getSelectionForeground()
                         : list.getForeground()
            );

            return box;
        }
    });

    lstIssues.addMouseListener(
        new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                int index = lstIssues.locationToIndex(e.getPoint());

                if (index >= 0) {
                    java.awt.Rectangle bounds =
                        lstIssues.getCellBounds(index, index);

                    if (bounds != null && bounds.contains(e.getPoint())) {
                        String issue =
                            lstIssues.getModel().getElementAt(index);

                        if (!checkedIssues.remove(issue)) {
                            checkedIssues.add(issue);
                        }

                        boolean isOther =
                            checkedIssues.contains("Other");

                        lblOtherIssue.setVisible(isOther);
                        txtOtherIssue.setVisible(isOther);

                        if (!isOther) {
                            txtOtherIssue.setText("");
                        }

                        lstIssues.repaint();
                    }
                }
            }
        }
    );
}

  public GadgetFrame(String username, String userRole) {

   
    initComponents();
    setupIssueCheckboxes();

    this.username = username;
    this.userRole = userRole;

    tblGadgets.setAutoResizeMode(
        javax.swing.JTable.AUTO_RESIZE_OFF
    );

    jScrollPane6.setHorizontalScrollBarPolicy(
        javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED
    );

    jScrollPane6.setVerticalScrollBarPolicy(
        javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED
    );

    lblOtherGadgetType.setVisible(false);
    txtOtherGadgetType.setVisible(false);
    lblOtherIssue.setVisible(false);
    txtOtherIssue.setVisible(false);

    cmbGadgetType.removeAllItems();
    cmbGadgetType.addItem("Select Gadget Type");
    cmbGadgetType.addItem("Mobile Phone");
    cmbGadgetType.addItem("Tablet");
    cmbGadgetType.addItem("Laptop");
    cmbGadgetType.addItem("Desktop Computer");
    cmbGadgetType.addItem("Smartwatch");
    cmbGadgetType.addItem("Game Console");
    cmbGadgetType.addItem("Other");

    setSize(1200, 750);
    setLocationRelativeTo(null);

    tblGadgets.setModel(new DefaultTableModel(
        new Object[][] {},
        new String[] {
            "Gadget ID",
            "Customer ID",
            "Type",
            "Brand/Model",
            "Problem"
        }
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    });

    setGadgetColumnWidths();

    tblGadgets.addMouseListener(new java.awt.event.MouseAdapter() {
        @Override
        public void mouseClicked(java.awt.event.MouseEvent e) {
            if (e.getClickCount() == 2) {
                int row = tblGadgets.rowAtPoint(e.getPoint());

                if (row >= 0) {
                    String problem =
                        tblGadgets.getValueAt(row, 4).toString();

                    JOptionPane.showMessageDialog(
                        GadgetFrame.this,
                        problem,
                        "Complete Gadget Problems",
                        JOptionPane.INFORMATION_MESSAGE
                    );
                }
            }
        }
    });

    tblCustomerResults.setModel(new DefaultTableModel(
        new Object[][] {},
        new String[] {
            "Customer ID",
            "Customer Name",
            "Contact Number"
        }
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    });

    txtGadgetId.setEditable(false);
    txtSelectedCustomerId.setEditable(false);
    txtSelectedCustomerName.setEditable(false);
    txtSelectedContact.setEditable(false);

    loadIssuesByGadgetType();
    refreshGadgetTable();
}

    private void refreshGadgetTable() {

        DefaultTableModel model =
        (DefaultTableModel) tblGadgets.getModel();

    model.setRowCount(0);

    String sql =
        "SELECT g.gadget_id, " +
        "g.customer_id, " +
        "gt.gadget_type_name, " +
        "g.brand_model, " +
        "g.problem " +
        "FROM gadgets g " +
        "JOIN gadget_types gt " +
        "ON g.gadget_type_id = gt.gadget_type_id " +
        "WHERE g.is_active = 1 " +
        "ORDER BY g.gadget_id ASC";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery()
    ) {

        while (rs.next()) {

            model.addRow(new Object[] {
                rs.getInt("gadget_id"),
                rs.getInt("customer_id"),
                rs.getString("gadget_type_name"),
                rs.getString("brand_model"),
                rs.getString("problem")
            });
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading gadgets:\n" + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
    setGadgetColumnWidths();
}



    private void clearGadgetForm() {

         txtGadgetId.setText("");

    txtSelectedCustomerId.setText("");
    txtSelectedCustomerName.setText("");
    txtSelectedContact.setText("");

    cmbGadgetType.setSelectedIndex(0);

    lstIssues.clearSelection();
    checkedIssues.clear();
lstIssues.repaint();

    txtOtherGadgetType.setText("");
    txtBrandModel.setText("");
    txtOtherIssue.setText("");

    lblOtherGadgetType.setVisible(false);
    txtOtherGadgetType.setVisible(false);

    lblOtherIssue.setVisible(false);
    txtOtherIssue.setVisible(false);

    tblGadgets.clearSelection();
    tblCustomerResults.clearSelection();

    editMode = false;
}

  

    private void clearCustomerResults() {

        DefaultTableModel model =
                (DefaultTableModel) tblCustomerResults.getModel();

        model.setRowCount(0);
    }

      

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        txtTitle = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtBrandModel = new javax.swing.JTextField();
        lblOtherIssue = new javax.swing.JLabel();
        btnAdd = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        txtGadgetId = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtCustomerSearch = new javax.swing.JTextField();
        btnSearchCustomer = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblCustomerResults = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        txtSelectedCustomerId = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtSelectedCustomerName = new javax.swing.JTextField();
        txtSelectedContact = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        btnSearch = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        txtGadgetSearch = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblGadgets = new javax.swing.JTable();
        cmbGadgetType = new javax.swing.JComboBox<>();
        lblOtherGadgetType = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        lstIssues = new javax.swing.JList<>();
        txtOtherGadgetType = new javax.swing.JTextField();
        txtOtherIssue = new javax.swing.JTextField();
        btnBack = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(245, 247, 250));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(18, 52, 86));
        jPanel1.setPreferredSize(new java.awt.Dimension(1000, 85));

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\LOGO REPAIRsss.png")); // NOI18N
        jLabel8.setPreferredSize(new java.awt.Dimension(135, 135));

        txtTitle.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        txtTitle.setForeground(new java.awt.Color(242, 242, 242));
        txtTitle.setText("GADGET MANAGEMENT");
        txtTitle.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(540, Short.MAX_VALUE)
                .addComponent(txtTitle)
                .addGap(274, 274, 274)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(txtTitle)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1560, 116));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jPanel2.setPreferredSize(new java.awt.Dimension(300, 230));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel9.setText("GADGET INFORMATION");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 56, 1490, 10));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel4.setText("Gadget Type:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 440, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(30, 41, 59));
        jLabel2.setText("Gadget ID:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel5.setText("Brand/Model:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 540, -1, -1));

        txtBrandModel.addActionListener(this::txtBrandModelActionPerformed);
        jPanel2.add(txtBrandModel, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 540, 300, 40));

        lblOtherIssue.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblOtherIssue.setText("Issue:");
        jPanel2.add(lblOtherIssue, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 590, 73, -1));

        btnAdd.setBackground(new java.awt.Color(24, 91, 160));
        btnAdd.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnAdd.setForeground(new java.awt.Color(255, 255, 255));
        btnAdd.setText("ADD");
        btnAdd.addActionListener(this::btnAddActionPerformed);
        jPanel2.add(btnAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 640, 87, -1));

        btnEdit.setBackground(new java.awt.Color(24, 91, 160));
        btnEdit.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnEdit.setForeground(new java.awt.Color(255, 255, 255));
        btnEdit.setText("EDIT");
        btnEdit.addActionListener(this::btnEditActionPerformed);
        jPanel2.add(btnEdit, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 640, 87, -1));

        btnSave.setBackground(new java.awt.Color(24, 91, 160));
        btnSave.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnSave.setForeground(new java.awt.Color(255, 255, 255));
        btnSave.setText("SAVE");
        btnSave.addActionListener(this::btnSaveActionPerformed);
        jPanel2.add(btnSave, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 640, 90, -1));

        txtGadgetId.setEditable(false);
        txtGadgetId.addActionListener(this::txtGadgetIdActionPerformed);
        jPanel2.add(txtGadgetId, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 70, 180, 30));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Search Customer:");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, -1, -1));
        jPanel2.add(txtCustomerSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 120, 300, 40));

        btnSearchCustomer.setBackground(new java.awt.Color(24, 91, 160));
        btnSearchCustomer.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnSearchCustomer.setForeground(new java.awt.Color(255, 255, 255));
        btnSearchCustomer.setText("Search");
        btnSearchCustomer.addActionListener(this::btnSearchCustomerActionPerformed);
        jPanel2.add(btnSearchCustomer, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 120, 120, -1));

        tblCustomerResults.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Customer ID", "Customer Name", "Contact Number"
            }
        ));
        tblCustomerResults.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblCustomerResultsMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tblCustomerResults);

        jScrollPane5.setViewportView(jScrollPane4);

        jPanel2.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 170, 450, 106));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel11.setText("Customer ID:");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 290, 150, -1));

        txtSelectedCustomerId.setEditable(false);
        txtSelectedCustomerId.addActionListener(this::txtSelectedCustomerIdActionPerformed);
        jPanel2.add(txtSelectedCustomerId, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 290, 180, 40));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel12.setText("Customer Name:");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, -1, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel13.setText("Contact Number:");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 400, -1, 25));

        txtSelectedCustomerName.setEditable(false);
        txtSelectedCustomerName.addActionListener(this::txtSelectedCustomerNameActionPerformed);
        jPanel2.add(txtSelectedCustomerName, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 340, 300, 40));

        txtSelectedContact.setEditable(false);
        txtSelectedContact.addActionListener(this::txtSelectedContactActionPerformed);
        jPanel2.add(txtSelectedContact, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 390, 300, 40));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jPanel3.setPreferredSize(new java.awt.Dimension(550, 330));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnSearch.setBackground(new java.awt.Color(24, 91, 160));
        btnSearch.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnSearch.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch.setText("Search");
        btnSearch.addActionListener(this::btnSearchActionPerformed);
        jPanel3.add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 60, -1, 30));

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        jPanel3.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 49, 710, 10));
        jPanel3.add(txtGadgetSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 60, 130, 30));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel7.setText("Search:");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, -1, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setText("GADGET RECORDS");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, -1, -1));

        tblGadgets.setBackground(new java.awt.Color(15, 43, 77));
        tblGadgets.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        tblGadgets.setForeground(new java.awt.Color(255, 255, 255));
        tblGadgets.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Gadget ID", "Customer ID", "Type", "Brand/Model", "Problem"
            }
        ));
        tblGadgets.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblGadgetsMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblGadgets);

        jScrollPane6.setViewportView(jScrollPane1);

        jPanel3.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 750, 380));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(726, 70, 760, 467));

        cmbGadgetType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbGadgetType.addActionListener(this::cmbGadgetTypeActionPerformed);
        jPanel2.add(cmbGadgetType, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 440, 300, 40));

        lblOtherGadgetType.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblOtherGadgetType.setText("Other:");
        jPanel2.add(lblOtherGadgetType, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 490, 80, -1));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel15.setText("Other:");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 640, 80, -1));

        lstIssues.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(lstIssues);

        jPanel2.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 590, 300, 110));
        jPanel2.add(txtOtherGadgetType, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 490, 300, 40));
        jPanel2.add(txtOtherIssue, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 640, 300, 40));

        btnBack.setBackground(new java.awt.Color(15, 43, 77));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(this::btnBackActionPerformed);
        jPanel2.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(1360, 640, 100, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 1500, 710));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
  if ("admin".equalsIgnoreCase(userRole)) {

            new AdminDashboardFrame(username).setVisible(true);

        } else {

            new DashboardFrame(username).setVisible(true);
        }

        this.dispose();
           
    }//GEN-LAST:event_btnBackActionPerformed

    private void txtGadgetIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGadgetIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGadgetIdActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

     
 int row = tblGadgets.getSelectedRow();

    if (row < 0) {
        JOptionPane.showMessageDialog(
                this,
                "Please select a gadget to edit."
        );
        return;
    }

    int gadgetId = Integer.parseInt(
            tblGadgets.getValueAt(row, 0).toString()
    );

    int customerId = Integer.parseInt(
            tblGadgets.getValueAt(row, 1).toString()
    );

    String gadgetType =
            tblGadgets.getValueAt(row, 2).toString();

    String brandModel =
            tblGadgets.getValueAt(row, 3).toString();

    String problem =
            tblGadgets.getValueAt(row, 4).toString();

    txtGadgetId.setText(String.valueOf(gadgetId));

    cmbGadgetType.setSelectedItem(gadgetType);
    txtBrandModel.setText(brandModel);

    loadIssuesByGadgetType();

    checkedIssues.clear();
    txtOtherIssue.setText("");
    lblOtherIssue.setVisible(false);
    txtOtherIssue.setVisible(false);

    String[] savedIssues = problem.split("\\s*\\|\\s*");

    javax.swing.ListModel<String> model =
            lstIssues.getModel();

    java.util.List<String> customIssues =
            new java.util.ArrayList<>();

    for (String issue : savedIssues) {
        boolean found = false;

        for (int i = 0; i < model.getSize(); i++) {
            String availableIssue = model.getElementAt(i);

            if (availableIssue.equals(issue)
                    && !availableIssue.equals("Other")) {

                checkedIssues.add(issue);
                found = true;
                break;
            }
        }

        if (!found && !issue.trim().isEmpty()) {
            customIssues.add(issue.trim());
        }
    }

    if (!customIssues.isEmpty()) {
        checkedIssues.add("Other");

        txtOtherIssue.setText(
                String.join(", ", customIssues)
        );

        lblOtherIssue.setVisible(true);
        txtOtherIssue.setVisible(true);
    }

    lstIssues.repaint();

    loadCustomerInformation(customerId);

    editMode = true;


       // TODO add your handling code here:
    }//GEN-LAST:event_btnEditActionPerformed

    private void txtBrandModelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBrandModelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBrandModelActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
String customerIdText =
    txtSelectedCustomerId.getText().trim();

if (customerIdText.isEmpty()) {
    JOptionPane.showMessageDialog(
        this,
        "Please search and select a customer first."
    );
    return;
}

if (cmbGadgetType.getSelectedIndex() == 0) {
    JOptionPane.showMessageDialog(
        this,
        "Please select a gadget type."
    );
    return;
}

String gadgetType =
    cmbGadgetType.getSelectedItem().toString();

if (gadgetType.equals("Other")) {
    gadgetType = txtOtherGadgetType.getText().trim();

    if (gadgetType.isEmpty()) {
        JOptionPane.showMessageDialog(
            this,
            "Please enter the gadget type."
        );
        return;
    }
}

String brandModel = txtBrandModel.getText().trim();

if (brandModel.isEmpty()) {
    JOptionPane.showMessageDialog(
        this,
        "Please enter the brand/model."
    );
    return;
}

java.util.List<String> selectedIssues =
    new java.util.ArrayList<>(checkedIssues);

if (selectedIssues.isEmpty()) {
    JOptionPane.showMessageDialog(
        this,
        "Please select at least one issue."
    );
    return;
}

java.util.List<String> finalIssues =
    new java.util.ArrayList<>();

for (String issue : selectedIssues) {
    if (issue.equals("Other")) {
        String otherIssue = txtOtherIssue.getText().trim();

        if (otherIssue.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Please enter the other issue."
            );
            return;
        }

        finalIssues.add(otherIssue);
    } else {
        finalIssues.add(issue);
    }
}

String problem = String.join(" | ", finalIssues);
try {
    int customerId = Integer.parseInt(customerIdText);

    int gadgetTypeId =
        getOrCreateGadgetTypeId(gadgetType);

    String sql =
        "INSERT INTO gadgets " +
        "(customer_id, gadget_type_id, brand_model, problem, is_active) " +
        "SELECT ?, ?, ?, ?, 1 " +
        "FROM customers " +
        "WHERE customer_id = ? " +
        "AND is_active = 1";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql)
    ) {
        pst.setInt(1, customerId);
        pst.setInt(2, gadgetTypeId);
        pst.setString(3, brandModel);
        pst.setString(4, problem);
        pst.setInt(5, customerId);

        int added = pst.executeUpdate();

        if (added == 0) {
            JOptionPane.showMessageDialog(
                this,
                "The selected customer does not exist or is archived."
            );
            return;
        }
    }

    JOptionPane.showMessageDialog(
        this,
        "Gadget added successfully!"
    );

    refreshGadgetTable();
    clearGadgetForm();

} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(
        this,
        "Invalid Customer ID."
    );

} catch (SQLException e) {
    JOptionPane.showMessageDialog(
        this,
        "Error adding gadget:\n" + e.getMessage(),
        "Database Error",
        JOptionPane.ERROR_MESSAGE
    );
}
   // TODO add your handling code here:
    }//GEN-LAST:event_btnAddActionPerformed

    private void tblGadgetsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblGadgetsMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tblGadgetsMouseClicked

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed

   String search =
        txtGadgetSearch.getText().trim();

    DefaultTableModel model =
        (DefaultTableModel) tblGadgets.getModel();

    model.setRowCount(0);

    if (search.isEmpty()) {
        refreshGadgetTable();
        return;
    }

    String sql =
        "SELECT g.gadget_id, " +
        "g.customer_id, " +
        "gt.gadget_type_name, " +
        "g.brand_model, " +
        "g.problem " +
        "FROM gadgets g " +
        "JOIN gadget_types gt " +
        "ON g.gadget_type_id = gt.gadget_type_id " +
        "WHERE g.is_active = 1 " +
        "AND (" +
        "CAST(g.gadget_id AS CHAR) LIKE ? " +
        "OR CAST(g.customer_id AS CHAR) LIKE ? " +
        "OR gt.gadget_type_name LIKE ? " +
        "OR g.brand_model LIKE ? " +
        "OR g.problem LIKE ?" +
        ") " +
        "ORDER BY g.gadget_id ASC";

    try (
        Connection conn =
            DatabaseConnection.getConnection();
        PreparedStatement pst =
            conn.prepareStatement(sql)
    ) {

        String keyword =
            "%" + search + "%";

        pst.setString(1, keyword);
        pst.setString(2, keyword);
        pst.setString(3, keyword);
        pst.setString(4, keyword);
        pst.setString(5, keyword);

        try (ResultSet rs =
                 pst.executeQuery()) {

            boolean found = false;

            while (rs.next()) {

                model.addRow(new Object[] {
                    rs.getInt("gadget_id"),
                    rs.getInt("customer_id"),
                    rs.getString("gadget_type_name"),
                    rs.getString("brand_model"),
                    rs.getString("problem")
                });

                found = true;
            }

            if (!found) {

                JOptionPane.showMessageDialog(
                    this,
                    "Gadget not found."
                );

                refreshGadgetTable();
            }
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error searching gadgets:\n"
            + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
          // TODO add your handling code here:
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed

  String gadgetIdText = txtGadgetId.getText().trim();
    String customerIdText = txtSelectedCustomerId.getText().trim();

    if (gadgetIdText.isEmpty()) {
        JOptionPane.showMessageDialog(this,
                "Please click EDIT on a gadget first.");
        return;
    }

    if (customerIdText.isEmpty()) {
        JOptionPane.showMessageDialog(this,
                "Please select a customer first.");
        return;
    }

    if (cmbGadgetType.getSelectedIndex() == 0) {
        JOptionPane.showMessageDialog(this,
                "Please select a gadget type.");
        return;
    }

    String gadgetType = cmbGadgetType.getSelectedItem().toString();

    if (gadgetType.equals("Other")) {
        gadgetType = txtOtherGadgetType.getText().trim();

        if (gadgetType.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter the gadget type.");
            return;
        }
    }

    String brandModel = txtBrandModel.getText().trim();

    if (brandModel.isEmpty()) {
        JOptionPane.showMessageDialog(this,
                "Please enter the brand/model.");
        return;
    }

    // Get the checked issues, not the selected list row.
    java.util.List<String> selectedIssues =
            new java.util.ArrayList<>(checkedIssues);

    if (selectedIssues.isEmpty()) {
        JOptionPane.showMessageDialog(this,
                "Please check at least one issue.");
        return;
    }

    java.util.List<String> finalIssues = new java.util.ArrayList<>();

    for (String issue : selectedIssues) {
        if (issue.equals("Other")) {
            String otherIssue = txtOtherIssue.getText().trim();

            if (otherIssue.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please enter the other issue.");
                return;
            }

            finalIssues.add(otherIssue);
        } else {
            finalIssues.add(issue);
        }
    }

    String problem = String.join(" | ", finalIssues);

    try {
        int gadgetId = Integer.parseInt(gadgetIdText);
        int customerId = Integer.parseInt(customerIdText);

        int gadgetTypeId = getOrCreateGadgetTypeId(gadgetType);

        String sql =
                "UPDATE gadgets SET " +
                "customer_id = ?, " +
                "gadget_type_id = ?, " +
                "brand_model = ?, " +
                "problem = ? " +
                "WHERE gadget_id = ? " +
                "AND is_active = 1";

        try (
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pst = conn.prepareStatement(sql)
        ) {
            pst.setInt(1, customerId);
            pst.setInt(2, gadgetTypeId);
            pst.setString(3, brandModel);
            pst.setString(4, problem);
            pst.setInt(5, gadgetId);

            int rowsUpdated = pst.executeUpdate();

            if (rowsUpdated == 0) {
                JOptionPane.showMessageDialog(this,
                        "Gadget could not be updated.");
                return;
            }
        }

        JOptionPane.showMessageDialog(this,
                "Gadget updated successfully!");

        refreshGadgetTable();
        clearGadgetForm();
        editMode = false;

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this,
                "Invalid Gadget ID or Customer ID.");

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
                this,
                "Error updating gadget:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
     // TODO add your handling code here:
    }//GEN-LAST:event_btnSaveActionPerformed

    private void tblCustomerResultsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblCustomerResultsMouseClicked

     if (editMode) {
    return;
}   
        int row = tblCustomerResults.getSelectedRow();

    if (row < 0) {
        return;
    }

    String customerId =
            tblCustomerResults.getValueAt(row, 0).toString();

    String customerName =
            tblCustomerResults.getValueAt(row, 1).toString();

    String contactNumber =
            tblCustomerResults.getValueAt(row, 2).toString();

    txtSelectedCustomerId.setText(customerId);
    txtSelectedCustomerName.setText(customerName);
    txtSelectedContact.setText(contactNumber);
    

   
// TODO add your handling code here:
    }//GEN-LAST:event_tblCustomerResultsMouseClicked

    private void btnSearchCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchCustomerActionPerformed
  String search =
            txtCustomerSearch.getText().trim();

    DefaultTableModel model =
            (DefaultTableModel) tblCustomerResults.getModel();

    model.setRowCount(0);

    if (search.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "Please enter a Customer ID, name, or contact number."
        );

        return;
    }

    String sql =
            "SELECT customer_id, first_name, " +
            "last_name, contact_number " +
            "FROM customers " +
            "WHERE is_active = 1 " +
            "AND (" +
            "CAST(customer_id AS CHAR) LIKE ? " +
            "OR first_name LIKE ? " +
            "OR last_name LIKE ? " +
            "OR contact_number LIKE ?" +
            ") " +
            "ORDER BY customer_id";

    try (
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pst = conn.prepareStatement(sql)
    ) {

        String keyword = "%" + search + "%";

        pst.setString(1, keyword);
        pst.setString(2, keyword);
        pst.setString(3, keyword);
        pst.setString(4, keyword);

        try (ResultSet rs = pst.executeQuery()) {

            boolean found = false;

            while (rs.next()) {

                String fullName =
                        rs.getString("first_name")
                        + " "
                        + rs.getString("last_name");

                model.addRow(new Object[]{
                    rs.getInt("customer_id"),
                    fullName,
                    rs.getString("contact_number")
                });

                found = true;
            }

            if (!found) {

                JOptionPane.showMessageDialog(
                        this,
                        "Customer not found."
                );
            }
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error searching customer:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSearchCustomerActionPerformed

    private void txtSelectedCustomerIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSelectedCustomerIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSelectedCustomerIdActionPerformed

    private void txtSelectedCustomerNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSelectedCustomerNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSelectedCustomerNameActionPerformed

    private void txtSelectedContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSelectedContactActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSelectedContactActionPerformed

    private void cmbGadgetTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbGadgetTypeActionPerformed

    loadIssuesByGadgetType();

    boolean isOther =
        "Other".equals(cmbGadgetType.getSelectedItem());

    lblOtherGadgetType.setVisible(isOther);
    txtOtherGadgetType.setVisible(isOther);

    if (!isOther) {
        txtOtherGadgetType.setText("");
    }   // TODO add your handling code here:
    }//GEN-LAST:event_cmbGadgetTypeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnSearchCustomer;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox<String> cmbGadgetType;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lblOtherGadgetType;
    private javax.swing.JLabel lblOtherIssue;
    private javax.swing.JList<String> lstIssues;
    private javax.swing.JTable tblCustomerResults;
    private javax.swing.JTable tblGadgets;
    private javax.swing.JTextField txtBrandModel;
    private javax.swing.JTextField txtCustomerSearch;
    private javax.swing.JTextField txtGadgetId;
    private javax.swing.JTextField txtGadgetSearch;
    private javax.swing.JTextField txtOtherGadgetType;
    private javax.swing.JTextField txtOtherIssue;
    private javax.swing.JTextField txtSelectedContact;
    private javax.swing.JTextField txtSelectedCustomerId;
    private javax.swing.JTextField txtSelectedCustomerName;
    private javax.swing.JLabel txtTitle;
    // End of variables declaration//GEN-END:variables
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package gadgetrepair.frames.staff;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;

/**
 *
 * @author User
 */
public class ReceiptDialog extends javax.swing.JDialog {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ReceiptDialog.class.getName());

    /**
     * Creates new form ReceiptDialog
     */
    public ReceiptDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
                setLocationRelativeTo(null);

    }

  public ReceiptDialog(
        java.awt.Frame parent,
        String repairId,
        String customer,
        String gadget,
        String problem,
        String technician,
        String dateBrought,
        String dateReturned,
        double laborFee,
        double partsTotal,
        String repairCost) {

    super(parent, true);
    initComponents();
    setLocationRelativeTo(parent);

    lblRepairIdValue.setText(repairId);
    lblCustomerValue.setText(customer);
    lblGadgetValue.setText(gadget);
    lblProblemValue.setText(problem);
    lblTechnicianValue.setText(technician);
    lblDateBroughtValue.setText(dateBrought);
    lblDateReturnedValue.setText(dateReturned);

    lblLaborFeeValue.setText(
        String.format(java.util.Locale.US, "₱%,.2f", laborFee)
    );

    lblPartsTotalValue.setText(
        String.format(java.util.Locale.US, "₱%,.2f", partsTotal)
    );

    lblRepairCostValue.setText(repairCost);
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtTitle = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lblRepairIdValue = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lblCustomerValue = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lblGadgetValue = new javax.swing.JLabel();
        lblDateBroughtValue = new javax.swing.JLabel();
        lblProblemValue = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        lblTechnicianValue = new javax.swing.JLabel();
        lblDateReturnedValue = new javax.swing.JLabel();
        btnPrint = new javax.swing.JButton();
        btnClose = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        lblRepairCostValue = new javax.swing.JLabel();
        txtTitle1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        lblPartsTotalValue = new javax.swing.JLabel();
        lblLaborFeeValue = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(18, 52, 86));
        jPanel1.setPreferredSize(new java.awt.Dimension(850, 80));

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\LOGO REPAIRsss.png")); // NOI18N
        jLabel8.setPreferredSize(new java.awt.Dimension(135, 135));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(242, 242, 242));
        jLabel2.setText("BALANG LOADING STATION ");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 30)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(242, 242, 242));
        jLabel4.setText("GADGET REPAIR & ACCESSORIES");

        txtTitle.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        txtTitle.setForeground(new java.awt.Color(242, 242, 242));
        txtTitle.setText("REPAIR RECEIPT");
        txtTitle.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtTitle)
                        .addGap(165, 165, 165)))
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(txtTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, 167));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Repair ID:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 250, -1, -1));

        lblRepairIdValue.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblRepairIdValue.setText("-");
        getContentPane().add(lblRepairIdValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 250, 310, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel3.setText("Customer:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 300, -1, -1));

        lblCustomerValue.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblCustomerValue.setText("-");
        getContentPane().add(lblCustomerValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 300, 310, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel5.setText("Gadget:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 350, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel6.setText("Problem:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 390, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel7.setText("Technician:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 430, -1, -1));

        lblGadgetValue.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblGadgetValue.setText("-");
        getContentPane().add(lblGadgetValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 350, 310, -1));

        lblDateBroughtValue.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblDateBroughtValue.setText("-");
        getContentPane().add(lblDateBroughtValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 480, 310, -1));

        lblProblemValue.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblProblemValue.setText("-");
        getContentPane().add(lblProblemValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 390, 310, -1));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel12.setText("Date Claimed:");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 520, -1, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel13.setText("Date Brought:");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 480, -1, -1));

        lblTechnicianValue.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblTechnicianValue.setText("-");
        getContentPane().add(lblTechnicianValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 430, 310, -1));

        lblDateReturnedValue.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblDateReturnedValue.setText("-");
        getContentPane().add(lblDateReturnedValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 520, 310, -1));

        btnPrint.setBackground(new java.awt.Color(24, 91, 160));
        btnPrint.setForeground(new java.awt.Color(242, 242, 242));
        btnPrint.setText("PRINT");
        btnPrint.setPreferredSize(new java.awt.Dimension(90, 35));
        btnPrint.addActionListener(this::btnPrintActionPerformed);
        getContentPane().add(btnPrint, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 770, -1, -1));

        btnClose.setText("CLOSE");
        btnClose.setPreferredSize(new java.awt.Dimension(90, 35));
        btnClose.addActionListener(this::btnCloseActionPerformed);
        getContentPane().add(btnClose, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 770, -1, -1));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel16.setText("Repair Cost:");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 680, -1, -1));

        lblRepairCostValue.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblRepairCostValue.setText("-");
        getContentPane().add(lblRepairCostValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 680, 306, -1));

        txtTitle1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        txtTitle1.setText("REPAIR INFORMATION");
        txtTitle1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(txtTitle1, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 185, -1, 28));

        jSeparator1.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 231, 740, 10));

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 740, 750, 10));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel9.setText("Labor Fee:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 580, 120, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel10.setText("Parts Total:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 620, -1, -1));

        lblPartsTotalValue.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblPartsTotalValue.setText("-");
        getContentPane().add(lblPartsTotalValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 620, 330, -1));

        lblLaborFeeValue.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblLaborFeeValue.setText("-");
        getContentPane().add(lblLaborFeeValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 580, 330, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrintActionPerformed
   PrinterJob job = PrinterJob.getPrinterJob();

    job.setPrintable((graphics, pageFormat, pageIndex) -> {

        if (pageIndex > 0) {
            return java.awt.print.Printable.NO_SUCH_PAGE;
        }

        java.awt.Graphics2D g2 = (java.awt.Graphics2D) graphics;

        g2.translate(
            pageFormat.getImageableX(),
            pageFormat.getImageableY()
        );

        g2.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 20));
        g2.drawString("GADGET REPAIR RECEIPT", 100, 40);

        g2.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 12));

        int y = 80;

        g2.drawString("Repair ID: " + lblRepairIdValue.getText(), 100, y);
        y += 25;

        g2.drawString("Customer: " + lblCustomerValue.getText(), 100, y);
        y += 25;

        g2.drawString("Gadget: " + lblGadgetValue.getText(), 100, y);
        y += 25;

        g2.drawString("Problem: " + lblProblemValue.getText(), 100, y);
        y += 25;

        g2.drawString("Technician: " + lblTechnicianValue.getText(), 100, y);
        y += 25;

        g2.drawString("Date Brought: " + lblDateBroughtValue.getText(), 100, y);
        y += 25;

        g2.drawString("Date Returned: " + lblDateReturnedValue.getText(), 100, y);
        y += 25;

        g2.drawString("Labor Fee: " + lblLaborFeeValue.getText(), 100, y);
        y += 25;

        g2.drawString("Parts Total: " + lblPartsTotalValue.getText(), 100, y);
        y += 25;

        g2.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        g2.drawString("Total Repair Cost: " + lblRepairCostValue.getText(), 100, y);
        return java.awt.print.Printable.PAGE_EXISTS;
    });

    boolean printAccepted = job.printDialog();

    if (printAccepted) {
        try {
            job.print();

            javax.swing.JOptionPane.showMessageDialog(
                this,
                "Receipt printed successfully!"
            );

        } catch (PrinterException e) {
            javax.swing.JOptionPane.showMessageDialog(
                this,
                "Error printing receipt:\n" + e.getMessage()
            );
        }
    }
      // TODO add your handling code here:
    }//GEN-LAST:event_btnPrintActionPerformed

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
  dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_btnCloseActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                ReceiptDialog dialog = new ReceiptDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClose;
    private javax.swing.JButton btnPrint;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lblCustomerValue;
    private javax.swing.JLabel lblDateBroughtValue;
    private javax.swing.JLabel lblDateReturnedValue;
    private javax.swing.JLabel lblGadgetValue;
    private javax.swing.JLabel lblLaborFeeValue;
    private javax.swing.JLabel lblPartsTotalValue;
    private javax.swing.JLabel lblProblemValue;
    private javax.swing.JLabel lblRepairCostValue;
    private javax.swing.JLabel lblRepairIdValue;
    private javax.swing.JLabel lblTechnicianValue;
    private javax.swing.JLabel txtTitle;
    private javax.swing.JLabel txtTitle1;
    // End of variables declaration//GEN-END:variables
}

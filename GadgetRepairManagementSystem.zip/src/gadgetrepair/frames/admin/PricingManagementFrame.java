/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gadgetrepair.frames.admin;
import gadgetrepair.frames.admin.AdminDashboardFrame;
import gadgetrepair.data.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class PricingManagementFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PricingManagementFrame.class.getName());
private String username;
private int selectedLaborPriceId = -1;
private int selectedPartId = -1;
   
private void loadLaborPrices() {

  DefaultTableModel model =
        (DefaultTableModel) tblLaborPrices.getModel();

    model.setRowCount(0);

    String sql =
    "SELECT lp.labor_price_id, " +
    "gt.gadget_type_name, " +
    "lp.issue_name, " +
    "lp.labor_fee " +
    "FROM labor_prices lp " +
    "JOIN gadget_types gt " +
    "ON lp.gadget_type_id = gt.gadget_type_id " +
    "WHERE lp.is_active = 1 " +
    "ORDER BY lp.labor_price_id ASC";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery()
    ) {

        while (rs.next()) {

            model.addRow(new Object[] {
                rs.getInt("labor_price_id"),
                rs.getString("gadget_type_name"),
                rs.getString("issue_name"),
                "₱" + rs.getBigDecimal("labor_fee")
            });
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading labor prices:\n" + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}

private void loadParts() {
DefaultTableModel model =
        (DefaultTableModel) tblParts.getModel();

    model.setRowCount(0);

    String sql =
        "SELECT p.part_id, " +
        "gt.gadget_type_name, " +
        "p.part_name, " +
        "p.part_price " +
        "FROM parts p " +
        "JOIN gadget_types gt " +
        "ON p.gadget_type_id = gt.gadget_type_id " +
        "WHERE p.is_active = 1 " +
        "ORDER BY p.part_id ASC";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery()
    ) {

        while (rs.next()) {

            model.addRow(new Object[] {
                rs.getInt("part_id"),
                rs.getString("gadget_type_name"),
                rs.getString("part_name"),
                "₱" + rs.getBigDecimal("part_price")
            });
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading parts:\n" + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}

private void loadIssuesByGadgetType() {

    cmbIssue.removeAllItems();

    String gadgetType =
        cmbGadgetType.getSelectedItem() == null
        ? ""
        : cmbGadgetType.getSelectedItem().toString();

    cmbIssue.addItem("Select Issue");

    switch (gadgetType) {

        case "Mobile Phone":
            cmbIssue.addItem("Screen/Display");
            cmbIssue.addItem("Battery");
            cmbIssue.addItem("Charging Port");
            cmbIssue.addItem("Camera");
            cmbIssue.addItem("Speaker/Microphone");
            cmbIssue.addItem("Software");
            cmbIssue.addItem("Other");
            break;

        case "Tablet":
            cmbIssue.addItem("Screen/Display");
            cmbIssue.addItem("Battery");
            cmbIssue.addItem("Charging Port");
            cmbIssue.addItem("Camera");
            cmbIssue.addItem("Speaker");
            cmbIssue.addItem("Software");
            cmbIssue.addItem("Other");
            break;

        case "Laptop":
            cmbIssue.addItem("Screen/Display");
            cmbIssue.addItem("Battery");
            cmbIssue.addItem("Keyboard");
            cmbIssue.addItem("Charging Port");
            cmbIssue.addItem("Overheating");
            cmbIssue.addItem("Software");
            cmbIssue.addItem("Other");
            break;

        case "Desktop Computer":
            cmbIssue.addItem("Power Problem");
            cmbIssue.addItem("No Display");
            cmbIssue.addItem("Overheating");
            cmbIssue.addItem("Operating System");
            cmbIssue.addItem("Hardware Problem");
            cmbIssue.addItem("Other");
            break;

        case "Smartwatch":
            cmbIssue.addItem("Screen/Display");
            cmbIssue.addItem("Battery");
            cmbIssue.addItem("Charging Problem");
            cmbIssue.addItem("Software");
            cmbIssue.addItem("Other");
            break;

        case "Game Console":
            cmbIssue.addItem("HDMI Port");
            cmbIssue.addItem("Power Problem");
            cmbIssue.addItem("Overheating");
            cmbIssue.addItem("Controller Problem");
            cmbIssue.addItem("Disc/Drive Problem");
            cmbIssue.addItem("Software");
            cmbIssue.addItem("Other");
            break;

        case "Other":
            cmbIssue.addItem("Other");
            break;
    }
}


private int getGadgetTypeId(String gadgetType) {

    String sql =
        "SELECT gadget_type_id " +
        "FROM gadget_types " +
        "WHERE gadget_type_name = ?";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql)
    ) {

        pst.setString(1, gadgetType);

        try (ResultSet rs = pst.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("gadget_type_id");
            }
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error getting gadget type:\n" + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }

    return -1;
}

private void updateOtherIssueVisibility() {
    boolean isOtherIssue =
        "Other".equals(cmbIssue.getSelectedItem());

    lblOtherIssue.setVisible(isOtherIssue);
    txtOtherIssue.setVisible(isOtherIssue);
}

private boolean partExists(
        int gadgetTypeId,
        String partName,
        int excludePartId) {

    String sql =
        "SELECT part_id FROM parts " +
        "WHERE gadget_type_id = ? " +
        "AND LOWER(part_name) = LOWER(?) " +
        "AND is_active = 1 " +
        "AND part_id <> ?";

    try (
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql)
    ) {
        pst.setInt(1, gadgetTypeId);
        pst.setString(2, partName);
        pst.setInt(3, excludePartId);

        try (ResultSet rs = pst.executeQuery()) {
            return rs.next();
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Error checking duplicate part:\n" + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
        return true;
    }
}

   public PricingManagementFrame(String username) {

    initComponents();

    this.username = username;

    setLocationRelativeTo(null);

  

    lblOtherGadgetType.setVisible(false);
    txtOtherGadgetType.setVisible(false);

    lblOtherIssue.setVisible(false);
    txtOtherIssue.setVisible(false);

  

    cmbGadgetType.removeAllItems();

    cmbGadgetType.addItem("Select Gadget Type");
    cmbGadgetType.addItem("Mobile Phone");
    cmbGadgetType.addItem("Tablet");
    cmbGadgetType.addItem("Laptop");
    cmbGadgetType.addItem("Desktop Computer");
    cmbGadgetType.addItem("Smartwatch");
    cmbGadgetType.addItem("Game Console");
    cmbGadgetType.addItem("Other");
    
    cmbPartGadgetType.removeAllItems();

    cmbPartGadgetType.addItem("Select Gadget Type");
    cmbPartGadgetType.addItem("Mobile Phone");
    cmbPartGadgetType.addItem("Tablet");
    cmbPartGadgetType.addItem("Laptop");
    cmbPartGadgetType.addItem("Desktop Computer");
    cmbPartGadgetType.addItem("Smartwatch");
    cmbPartGadgetType.addItem("Game Console");
    cmbPartGadgetType.addItem("Other");

  

    cmbIssue.removeAllItems();
    cmbIssue.addItem("Select Issue");

   

    tblLaborPrices.setModel(new DefaultTableModel(
        new Object[][] {},
        new String[] {
            "Price ID",
            "Gadget Type",
            "Issue",
            "Labor Fee"
        }
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    });

    

   tblParts.setModel(new DefaultTableModel(
    new Object[][] {},
    new String[] {
        "Part ID",
        "Gadget Type",
        "Part Name",
        "Part Price"
    }
) {
    @Override
    public boolean isCellEditable(int row, int column) {
        return false;
    }
});

    
    loadLaborPrices();
    loadParts();
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtTitle = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        lblGadgetType = new javax.swing.JLabel();
        cmbGadgetType = new javax.swing.JComboBox<>();
        lblIssue = new javax.swing.JLabel();
        cmbIssue = new javax.swing.JComboBox<>();
        lblLaborFee = new javax.swing.JLabel();
        txtLaborFee = new javax.swing.JTextField();
        btnSaveLabor = new javax.swing.JButton();
        btnEditLabor = new javax.swing.JButton();
        lblOtherGadgetType = new javax.swing.JLabel();
        txtOtherGadgetType = new javax.swing.JTextField();
        lblOtherIssue = new javax.swing.JLabel();
        txtOtherIssue = new javax.swing.JTextField();
        lblPartName = new javax.swing.JLabel();
        txtPartName = new javax.swing.JTextField();
        lblPartPrice = new javax.swing.JLabel();
        txtPartPrice = new javax.swing.JTextField();
        btnSavePart = new javax.swing.JButton();
        btnEditPart = new javax.swing.JButton();
        lblPartGadgetType = new javax.swing.JLabel();
        cmbPartGadgetType = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblParts = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        jScrollPane5 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblLaborPrices = new javax.swing.JTable();
        btnBack = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(18, 52, 86));
        jPanel1.setPreferredSize(new java.awt.Dimension(900, 80));

        txtTitle.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        txtTitle.setForeground(new java.awt.Color(242, 242, 242));
        txtTitle.setText("PRICE MANAGEMENT");
        txtTitle.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\LOGO REPAIRsss.png")); // NOI18N
        jLabel8.setPreferredSize(new java.awt.Dimension(135, 135));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(577, Short.MAX_VALUE)
                .addComponent(txtTitle)
                .addGap(255, 255, 255)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(txtTitle)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1520, 116));

        lblGadgetType.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblGadgetType.setText("Gadget Type:");
        getContentPane().add(lblGadgetType, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 160, 150, -1));

        cmbGadgetType.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cmbGadgetType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbGadgetType.addActionListener(this::cmbGadgetTypeActionPerformed);
        getContentPane().add(cmbGadgetType, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 200, 40));

        lblIssue.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblIssue.setText("Issue:");
        getContentPane().add(lblIssue, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 280, 70, -1));

        cmbIssue.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cmbIssue.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbIssue.addActionListener(this::cmbIssueActionPerformed);
        getContentPane().add(cmbIssue, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 280, 200, 40));

        lblLaborFee.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblLaborFee.setText("Labor Fee:");
        getContentPane().add(lblLaborFee, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 400, -1, -1));

        txtLaborFee.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtLaborFee, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 400, 200, 40));

        btnSaveLabor.setBackground(new java.awt.Color(24, 91, 160));
        btnSaveLabor.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnSaveLabor.setForeground(new java.awt.Color(255, 255, 255));
        btnSaveLabor.setText("Save Labor Price");
        btnSaveLabor.addActionListener(this::btnSaveLaborActionPerformed);
        getContentPane().add(btnSaveLabor, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 450, 200, -1));

        btnEditLabor.setBackground(new java.awt.Color(24, 91, 160));
        btnEditLabor.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnEditLabor.setForeground(new java.awt.Color(255, 255, 255));
        btnEditLabor.setText("Edit");
        btnEditLabor.addActionListener(this::btnEditLaborActionPerformed);
        getContentPane().add(btnEditLabor, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 450, 90, -1));

        lblOtherGadgetType.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblOtherGadgetType.setText("Other Gadget Type:");
        getContentPane().add(lblOtherGadgetType, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 220, 210, -1));

        txtOtherGadgetType.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtOtherGadgetType, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 220, 200, 40));

        lblOtherIssue.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblOtherIssue.setText("Other Issue:");
        getContentPane().add(lblOtherIssue, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 340, 140, -1));

        txtOtherIssue.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtOtherIssue.addActionListener(this::txtOtherIssueActionPerformed);
        getContentPane().add(txtOtherIssue, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 340, 200, 40));

        lblPartName.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblPartName.setText("Part Name:");
        getContentPane().add(lblPartName, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 220, 140, -1));

        txtPartName.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtPartName, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 220, 200, 40));

        lblPartPrice.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblPartPrice.setText("Part Price:");
        getContentPane().add(lblPartPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 280, 110, -1));

        txtPartPrice.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtPartPrice.addActionListener(this::txtPartPriceActionPerformed);
        getContentPane().add(txtPartPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 280, 200, 40));

        btnSavePart.setBackground(new java.awt.Color(24, 91, 160));
        btnSavePart.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnSavePart.setForeground(new java.awt.Color(255, 255, 255));
        btnSavePart.setText("Save Part");
        btnSavePart.addActionListener(this::btnSavePartActionPerformed);
        getContentPane().add(btnSavePart, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 350, 200, -1));

        btnEditPart.setBackground(new java.awt.Color(24, 91, 160));
        btnEditPart.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnEditPart.setForeground(new java.awt.Color(255, 255, 255));
        btnEditPart.setText("Edit");
        btnEditPart.addActionListener(this::btnEditPartActionPerformed);
        getContentPane().add(btnEditPart, new org.netbeans.lib.awtextra.AbsoluteConstraints(1260, 350, 90, -1));

        lblPartGadgetType.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblPartGadgetType.setText("Gadget Type:");
        getContentPane().add(lblPartGadgetType, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 160, 160, -1));

        cmbPartGadgetType.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        cmbPartGadgetType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        getContentPane().add(cmbPartGadgetType, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 160, 200, -1));

        tblParts.setBackground(new java.awt.Color(15, 43, 77));
        tblParts.setForeground(new java.awt.Color(255, 255, 255));
        tblParts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Part ID", "Gadget Type", "Part Name", "Part Price"
            }
        ));
        tblParts.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPartsMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblParts);

        jScrollPane3.setViewportView(jScrollPane2);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 500, 680, 340));
        getContentPane().add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 460, -1, -1));

        tblLaborPrices.setBackground(new java.awt.Color(15, 43, 77));
        tblLaborPrices.setForeground(new java.awt.Color(255, 255, 255));
        tblLaborPrices.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Price ID", "Gadget Type", "Issue", "Labor Fee"
            }
        ));
        tblLaborPrices.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblLaborPricesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblLaborPrices);

        jScrollPane5.setViewportView(jScrollPane1);

        getContentPane().add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 500, 740, 340));

        btnBack.setBackground(new java.awt.Color(15, 43, 77));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(this::btnBackActionPerformed);
        getContentPane().add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 90, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbGadgetTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbGadgetTypeActionPerformed
loadIssuesByGadgetType();

    boolean isOtherGadget =
        "Other".equals(cmbGadgetType.getSelectedItem());

    lblOtherGadgetType.setVisible(isOtherGadget);
    txtOtherGadgetType.setVisible(isOtherGadget);

    updateOtherIssueVisibility();
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbGadgetTypeActionPerformed

    private void txtOtherIssueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtOtherIssueActionPerformed
  boolean isOtherIssue =
        "Other".equals(cmbIssue.getSelectedItem());

    lblOtherIssue.setVisible(isOtherIssue);
    txtOtherIssue.setVisible(isOtherIssue);        // TODO add your handling code here:
    }//GEN-LAST:event_txtOtherIssueActionPerformed

    private void btnSaveLaborActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveLaborActionPerformed
 String gadgetType =
        cmbGadgetType.getSelectedItem() == null
        ? ""
        : cmbGadgetType.getSelectedItem().toString();

    String issue =
        cmbIssue.getSelectedItem() == null
        ? ""
        : cmbIssue.getSelectedItem().toString();

    if (cmbGadgetType.getSelectedIndex() == 0) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a gadget type."
        );
        return;
    }

    if (cmbIssue.getSelectedIndex() == 0) {
        JOptionPane.showMessageDialog(
            this,
            "Please select an issue."
        );
        return;
    }

    if ("Other".equals(issue)) {

        issue = txtOtherIssue.getText().trim();

        if (issue.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Please enter the other issue."
            );
            return;
        }
    }

    int gadgetTypeId =
        getGadgetTypeId(gadgetType);

    if (gadgetTypeId == -1) {
        JOptionPane.showMessageDialog(
            this,
            "Gadget type was not found."
        );
        return;
    }

    String laborFeeText =
        txtLaborFee.getText().trim();

    if (laborFeeText.isEmpty()) {
        JOptionPane.showMessageDialog(
            this,
            "Please enter the labor fee."
        );
        return;
    }

    double laborFee;

    try {

        laborFee =
            Double.parseDouble(laborFeeText);

        if (laborFee < 0) {
            JOptionPane.showMessageDialog(
                this,
                "Labor fee cannot be negative."
            );
            return;
        }

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
            this,
            "Please enter a valid labor fee."
        );
        return;
    }

    String sql =
        "INSERT INTO labor_prices " +
        "(gadget_type_id, issue_name, labor_fee, is_active) " +
        "VALUES (?, ?, ?, 1)";

    try (
        Connection conn =
            DatabaseConnection.getConnection();
        PreparedStatement pst =
            conn.prepareStatement(sql)
    ) {

        pst.setInt(1, gadgetTypeId);
        pst.setString(2, issue);
        pst.setDouble(3, laborFee);

        pst.executeUpdate();

        JOptionPane.showMessageDialog(
            this,
            "Labor price saved successfully!"
        );

        loadLaborPrices();

        cmbGadgetType.setSelectedIndex(0);

        cmbIssue.removeAllItems();
        cmbIssue.addItem("Select Issue");

        txtLaborFee.setText("");
        txtOtherGadgetType.setText("");
        txtOtherIssue.setText("");

        lblOtherGadgetType.setVisible(false);
        txtOtherGadgetType.setVisible(false);
        lblOtherIssue.setVisible(false);
        txtOtherIssue.setVisible(false);

    } catch (SQLException e) {

        if (e.getMessage() != null &&
            e.getMessage().toLowerCase().contains("duplicate")) {

            JOptionPane.showMessageDialog(
                this,
                "A labor price for this gadget type and issue already exists."
            );

        } else {

            JOptionPane.showMessageDialog(
                this,
                "Error saving labor price:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }      // TODO add your handling code here:
    }//GEN-LAST:event_btnSaveLaborActionPerformed

    private void tblLaborPricesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblLaborPricesMouseClicked

    int row = tblLaborPrices.getSelectedRow();

    if (row < 0) {
        return;
    }

    selectedLaborPriceId =
        Integer.parseInt(
            tblLaborPrices.getValueAt(row, 0).toString()
        );

    String gadgetType =
        tblLaborPrices.getValueAt(row, 1).toString();

    String issue =
        tblLaborPrices.getValueAt(row, 2).toString();

    String laborFee =
        tblLaborPrices.getValueAt(row, 3).toString();

    cmbGadgetType.setSelectedItem(gadgetType);

    loadIssuesByGadgetType();

    cmbIssue.setSelectedItem(issue);

    txtLaborFee.setText(
        laborFee.replace("₱", "").trim()
    );
        // TODO add your handling code here:
    }//GEN-LAST:event_tblLaborPricesMouseClicked

    private void btnEditLaborActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditLaborActionPerformed
   if (selectedLaborPriceId == -1) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a labor price from the table."
        );
        return;
    }

    String gadgetType =
        cmbGadgetType.getSelectedItem() == null
        ? ""
        : cmbGadgetType.getSelectedItem().toString();

    String issue =
        cmbIssue.getSelectedItem() == null
        ? ""
        : cmbIssue.getSelectedItem().toString();

    if (cmbGadgetType.getSelectedIndex() == 0) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a gadget type."
        );
        return;
    }

    if (cmbIssue.getSelectedIndex() == 0) {
        JOptionPane.showMessageDialog(
            this,
            "Please select an issue."
        );
        return;
    }

    if ("Other".equals(issue)) {

        issue = txtOtherIssue.getText().trim();

        if (issue.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Please enter the other issue."
            );
            return;
        }
    }

    int gadgetTypeId =
        getGadgetTypeId(gadgetType);

    if (gadgetTypeId == -1) {
        JOptionPane.showMessageDialog(
            this,
            "Gadget type was not found."
        );
        return;
    }

    String laborFeeText =
        txtLaborFee.getText().trim();

    if (laborFeeText.isEmpty()) {
        JOptionPane.showMessageDialog(
            this,
            "Please enter the labor fee."
        );
        return;
    }

    double laborFee;

    try {

        laborFee =
            Double.parseDouble(laborFeeText);

        if (laborFee < 0) {
            JOptionPane.showMessageDialog(
                this,
                "Labor fee cannot be negative."
            );
            return;
        }

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
            this,
            "Please enter a valid labor fee."
        );
        return;
    }

    String sql =
        "UPDATE labor_prices " +
        "SET gadget_type_id = ?, " +
        "issue_name = ?, " +
        "labor_fee = ? " +
        "WHERE labor_price_id = ? " +
        "AND is_active = 1";

    try (
        Connection conn =
            DatabaseConnection.getConnection();
        PreparedStatement pst =
            conn.prepareStatement(sql)
    ) {

        pst.setInt(1, gadgetTypeId);
        pst.setString(2, issue);
        pst.setDouble(3, laborFee);
        pst.setInt(4, selectedLaborPriceId);

        int rowsUpdated =
            pst.executeUpdate();

        if (rowsUpdated > 0) {

            JOptionPane.showMessageDialog(
                this,
                "Labor price updated successfully!"
            );

            loadLaborPrices();

            selectedLaborPriceId = -1;

            cmbGadgetType.setSelectedIndex(0);

            cmbIssue.removeAllItems();
            cmbIssue.addItem("Select Issue");

            txtLaborFee.setText("");
            txtOtherGadgetType.setText("");
            txtOtherIssue.setText("");

            lblOtherGadgetType.setVisible(false);
            txtOtherGadgetType.setVisible(false);
            lblOtherIssue.setVisible(false);
            txtOtherIssue.setVisible(false);

        } else {

            JOptionPane.showMessageDialog(
                this,
                "Labor price could not be updated."
            );
        }

    } catch (SQLException e) {

        if (e.getMessage() != null &&
            e.getMessage().toLowerCase().contains("duplicate")) {

            JOptionPane.showMessageDialog(
                this,
                "A labor price for this gadget type and issue already exists."
            );

        } else {

            JOptionPane.showMessageDialog(
                this,
                "Error updating labor price:\n"
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }       // TODO add your handling code here:
    }//GEN-LAST:event_btnEditLaborActionPerformed

    private void btnSavePartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSavePartActionPerformed
  if (cmbPartGadgetType.getSelectedIndex() == 0) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a gadget type."
        );
        return;
    }

    String gadgetType =
        cmbPartGadgetType.getSelectedItem().toString();

    String partName =
        txtPartName.getText().trim();

    String priceText =
        txtPartPrice.getText().trim();

    if (partName.isEmpty()) {
        JOptionPane.showMessageDialog(
            this,
            "Please enter a part name."
        );
        return;
    }

    if (priceText.isEmpty()) {
        JOptionPane.showMessageDialog(
            this,
            "Please enter the part price."
        );
        return;
    }
    
    int gadgetTypeId = getGadgetTypeId(gadgetType);

if (gadgetTypeId == -1) {
    JOptionPane.showMessageDialog(
        this, "Gadget type was not found."
    );
    return;
}

if (partExists(gadgetTypeId, partName, -1)) {
    JOptionPane.showMessageDialog(
        this,
        "This part already exists for the selected gadget type."
    );
    return;
}

    double partPrice;

    try {

        partPrice =
            Double.parseDouble(priceText);

        if (partPrice < 0) {
            JOptionPane.showMessageDialog(
                this,
                "Part price cannot be negative."
            );
            return;
        }

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
            this,
            "Please enter a valid part price."
        );
        return;
    }

   String sql =
    "INSERT INTO parts " +
    "(gadget_type_id, part_name, part_price, is_active) " +
    "VALUES (?, ?, ?, 1)";

try (
    Connection conn = DatabaseConnection.getConnection();
    PreparedStatement pst = conn.prepareStatement(sql)
) {
    pst.setInt(1, gadgetTypeId);
    pst.setString(2, partName);
    pst.setDouble(3, partPrice);

    int rowsInserted = pst.executeUpdate();

    if (rowsInserted > 0) {
        JOptionPane.showMessageDialog(
            this, "Part saved successfully!"
        );

        loadParts();
selectedPartId = -1;
cmbPartGadgetType.setSelectedIndex(0);
txtPartName.setText("");
txtPartPrice.setText("");    }

} catch (SQLException e) {
    JOptionPane.showMessageDialog(
        this,
        "Error saving part:\n" + e.getMessage(),
        "Database Error",
        JOptionPane.ERROR_MESSAGE
    );
}     // TODO add your handling code here:
    }//GEN-LAST:event_btnSavePartActionPerformed

    private void tblPartsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPartsMouseClicked

    int row = tblParts.getSelectedRow();

    if (row < 0) {
        return;
    }

    selectedPartId =
        Integer.parseInt(
            tblParts.getValueAt(row, 0).toString()
        );

    String gadgetType =
        tblParts.getValueAt(row, 1).toString();

    String partName =
        tblParts.getValueAt(row, 2).toString();

    String partPrice =
        tblParts.getValueAt(row, 3).toString();

    cmbPartGadgetType.setSelectedItem(gadgetType);

    txtPartName.setText(partName);

    txtPartPrice.setText(
        partPrice.replace("₱", "").trim()
    );


// TODO add your handling code here:
    }//GEN-LAST:event_tblPartsMouseClicked

    private void btnEditPartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditPartActionPerformed

  if (selectedPartId == -1) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a part from the table."
        );
        return;
    }

    if (cmbPartGadgetType.getSelectedIndex() == 0) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a gadget type."
        );
        return;
    }

    String gadgetType =
        cmbPartGadgetType.getSelectedItem().toString();

    String partName =
        txtPartName.getText().trim();

    String priceText =
        txtPartPrice.getText().trim();

    if (partName.isEmpty()) {
        JOptionPane.showMessageDialog(
            this,
            "Please enter a part name."
        );
        return;
    }

    if (priceText.isEmpty()) {
        JOptionPane.showMessageDialog(
            this,
            "Please enter the part price."
        );
        return;
    }
    
    int gadgetTypeId = getGadgetTypeId(gadgetType);

if (gadgetTypeId == -1) {
    JOptionPane.showMessageDialog(
        this, "Gadget type was not found."
    );
    return;
}

if (partExists(gadgetTypeId, partName, selectedPartId)) {
    JOptionPane.showMessageDialog(
        this,
        "Another part with this name already exists for the selected gadget type."
    );
    return;
}

    double partPrice;

    try {

        partPrice =
            Double.parseDouble(priceText);

        if (partPrice < 0) {
            JOptionPane.showMessageDialog(
                this,
                "Part price cannot be negative."
            );
            return;
        }

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
            this,
            "Please enter a valid part price."
        );
        return;
    }

  String sql =
    "UPDATE parts " +
    "SET gadget_type_id = ?, part_name = ?, part_price = ? " +
    "WHERE part_id = ? AND is_active = 1";

try (
    Connection conn = DatabaseConnection.getConnection();
    PreparedStatement pst = conn.prepareStatement(sql)
) {
    pst.setInt(1, gadgetTypeId);
    pst.setString(2, partName);
    pst.setDouble(3, partPrice);
    pst.setInt(4, selectedPartId);

    int rowsUpdated = pst.executeUpdate();

    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(
            this, "Part updated successfully!"
        );

        loadParts();

        selectedPartId = -1;
        cmbPartGadgetType.setSelectedIndex(0);
        txtPartName.setText("");
        txtPartPrice.setText("");
    } else {
        JOptionPane.showMessageDialog(
            this, "Part could not be updated."
        );
    }

} catch (SQLException e) {
    JOptionPane.showMessageDialog(
        this,
        "Error updating part:\n" + e.getMessage(),
        "Database Error",
        JOptionPane.ERROR_MESSAGE
    );
}// TODO add your handling code here:
    }//GEN-LAST:event_btnEditPartActionPerformed

    private void txtPartPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPartPriceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPartPriceActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
     AdminDashboardFrame admin = new AdminDashboardFrame(username);
    admin.setVisible(true);
    this.dispose();       // TODO add your handling code here:
    }//GEN-LAST:event_btnBackActionPerformed

    private void cmbIssueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbIssueActionPerformed
 
        
        updateOtherIssueVisibility();        // TODO add your handling code here:
    }//GEN-LAST:event_cmbIssueActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnEditLabor;
    private javax.swing.JButton btnEditPart;
    private javax.swing.JButton btnSaveLabor;
    private javax.swing.JButton btnSavePart;
    private javax.swing.JComboBox<String> cmbGadgetType;
    private javax.swing.JComboBox<String> cmbIssue;
    private javax.swing.JComboBox<String> cmbPartGadgetType;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JLabel lblGadgetType;
    private javax.swing.JLabel lblIssue;
    private javax.swing.JLabel lblLaborFee;
    private javax.swing.JLabel lblOtherGadgetType;
    private javax.swing.JLabel lblOtherIssue;
    private javax.swing.JLabel lblPartGadgetType;
    private javax.swing.JLabel lblPartName;
    private javax.swing.JLabel lblPartPrice;
    private javax.swing.JTable tblLaborPrices;
    private javax.swing.JTable tblParts;
    private javax.swing.JTextField txtLaborFee;
    private javax.swing.JTextField txtOtherGadgetType;
    private javax.swing.JTextField txtOtherIssue;
    private javax.swing.JTextField txtPartName;
    private javax.swing.JTextField txtPartPrice;
    private javax.swing.JLabel txtTitle;
    // End of variables declaration//GEN-END:variables
}
